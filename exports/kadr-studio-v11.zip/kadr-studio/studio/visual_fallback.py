"""Complete automatic films without random pictures or missing-media failures."""
from .models import Scene, frame_count


def text_scene(project, index):
    scene=project.scenes[index]
    start=sum(frame_count(s) for s in project.scenes[:index])/30
    end=start+frame_count(scene)/30
    cues=[c for c in project.subtitles if c.start<end and c.end>start]
    text=' '.join(c.text.replace('\n',' ') for c in cues).strip() or scene.title or scene.caption or project.name
    if len(text)>160:text=text[:157].rsplit(' ',1)[0]+'…'
    from .narration import has_stem
    heading='ЭФИОПИЯ' if has_stem(('эфиоп','ethiop'),text) else 'ГРЕЧЕСКАЯ КОПИЯ' if has_stem(('гречес','greek'),text) else text
    body=text if heading!=text else ''
    values=scene.model_dump()
    values.update(text_events=scene.text_events,automatic_text=True,template='thesis',asset_id=None,offset=0,title=heading,caption=body,
                  title_layout='folio',title_effect='fade',title_delay=0,title_end=None,
                  title_duration=.4,title_decoration='none',title_exit=False,
                  title_sound='none',picture_effect='plain',motion=False,
                  media_reason='Текстовая композиция из озвучки: подходящий фото- или видеоматериал не найден.')
    return Scene.model_validate(values)


def complete_visuals(project):
    """Offline last resort for saved v9 projects and interrupted media searches.

    Reuse a described matching picture if available; otherwise compose supplied
    narration as typography. Never replace it with a random demo landscape.
    """
    if project.director_version<9:return project
    from .auto_media import local_assets,scene_context,relevant_candidate,rank_candidate
    result=project.model_copy(deep=True)
    library=local_assets()
    for index,scene in enumerate(result.scenes):
        if scene.asset_id or scene.template in ('quote','thesis'):continue
        try:
            context=scene_context(result,index)
            allowed={'photos':{'image'},'videos':{'video'},'mixed':{'image','video'}}[project.auto_media_mode]
            candidates=[] if context.get('text_only') else [a for a in library if a['kind'] in allowed and relevant_candidate(a,context,local=True)]
        except ValueError:candidates=[]
        if candidates:
            asset=max(candidates,key=lambda a:rank_candidate(a,context,scene.duration,local=True))
            scene.asset_id=asset['id'];scene.offset=0;scene.motion=False
            scene.media_reason='Повтор подходящего материала по теме: '+context['concept']
        else:result.scenes[index]=text_scene(result,index)
    return result
