"""Frame-aligned transitions and original synthesized transition sound effects."""
import math
import random
import wave
from array import array
from pathlib import Path

from .media import run
from .models import Project, frame_count, total_duration
from .video_clock import normalize_clock, require_frames

TRANSITIONS = {'dissolve': 'fade', 'slide': 'smoothleft', 'flash': 'fadewhite',
               'blur': 'hblur', 'wipe': 'wipeleft'}
CYCLE = ('dissolve', 'slide', 'flash', 'blur', 'wipe')


def boundary_style(project: Project, index: int) -> str:
    override = project.scenes[index].transition_out
    if override != 'inherit':
        return override
    if project.transition == 'mixed':
        return CYCLE[index % len(CYCLE)]
    return project.transition if project.transition in TRANSITIONS else 'cut'


def transition_frames(project: Project, index: int) -> int:
    if index >= len(project.scenes)-1 or boundary_style(project, index) == 'cut':
        return 0
    # Leave readable time even in a one-second scene.
    return min(12, frame_count(project.scenes[index+1])//3)


def encode_segment(args: list[str], graph: str, frames: int, output: Path):
    run(['ffmpeg', '-v', 'error', '-y', '-filter_complex_threads', '1', *args,
         '-filter_complex', graph, '-map', '[out]', '-an', '-frames:v', str(frames),
         '-r', '30', '-fps_mode', 'cfr', '-c:v', 'libx264', '-preset', 'veryfast',
         '-crf', '20', '-threads', '2', '-video_track_timescale', '15360', str(output)], timeout=600)


def assemble(project: Project, pieces: list[Path], folder: Path, progress) -> Path:
    """Render only two adjacent handles at a time, avoiding an unbounded xfade graph.

    Each outgoing scene has a spare handle after its nominal end. Blend it with
    the first frames of the next scene, then consume those frames from its core.
    Result: no accumulated timeline shortening; SRT and voice remain absolute.
    """
    segments = []
    for index,piece in enumerate(pieces):
        expected=frame_count(project.scenes[index])+transition_frames(project,index)
        if not normalize_clock(piece,expected):require_frames(piece,expected)
    for index, (scene, piece) in enumerate(zip(project.scenes, pieces)):
        incoming = transition_frames(project, index-1) if index else 0
        outgoing = transition_frames(project, index)
        frames = frame_count(scene)
        if not incoming and not outgoing:
            segments.append(piece)
        else:
            core = folder / f'core-{index:03d}.mp4'
            graph = f'[0:v]trim=start_frame={incoming}:end_frame={frames},setpts=N/(30*TB),format=yuv420p[out]'
            encode_segment(['-i', str(piece)], graph, frames-incoming, core)
            segments.append(core)
        if outgoing:
            progress(73+int(index/len(pieces)*13), f'Переход {index+1}: {boundary_style(project,index)}')
            transition = folder / f'transition-{index:03d}.mp4'
            graph = (f'[0:v]trim=start_frame={frames}:end_frame={frames+outgoing},setpts=N/(30*TB),fps=30,settb=1/30[a];'
                     f'[1:v]trim=end_frame={outgoing},setpts=N/(30*TB),fps=30,settb=1/30[b];'
                     f'[a][b]xfade=transition={TRANSITIONS[boundary_style(project,index)]}:duration={outgoing/30}:offset=0,'
                     'format=yuv420p[out]')
            encode_segment(['-i', str(piece), '-i', str(pieces[index+1])], graph, outgoing, transition)
            segments.append(transition)
    concat = folder / 'concat.txt'
    concat.write_text(''.join(f"file '{p.name}'\n" for p in segments))
    video = folder / 'picture.mp4'
    progress(85,'Сборка видеодорожки')
    # Independently encoded segments can carry differing AVC parameter sets.
    # A single final encode gives players one consistent stream and seek index.
    run(['ffmpeg','-v','error','-y','-f','concat','-safe','1','-i',str(concat),
         '-vf','settb=1/30,setpts=N,fps=30,setsar=1,format=yuv420p',
         '-frames:v',str(sum(frame_count(s) for s in project.scenes)),
         '-an','-r','30','-c:v','libx264','-preset','veryfast','-crf','20','-threads','2',
         '-g','60','-keyint_min','30','-video_track_timescale','15360','-movflags','+faststart',str(video)],timeout=600)
    require_frames(video,sum(frame_count(s) for s in project.scenes))
    return video


def synthesize_sfx(project: Project, output: Path) -> bool:
    if project.sfx_volume == 0:
        return False
    rate = 48000
    from .soundplan import sound_plan
    plan=sound_plan(project)
    if not plan:return False
    count=math.ceil(total_duration(project)*rate)
    samples=array('f',[0.0])*(count*2)
    for index,event in enumerate(plan):
        rng=random.Random(2100+index);style=event['style']
        click=style=='click';impact=style in ('impact','flash')
        # Automatic event time is the motion peak. Manual clicks retain their exact onset.
        lead=0 if click else .09 if impact else .22
        start=event['time']-lead
        length=.18 if click else .72 if impact else .62
        low=mid=other=0.0
        for j in range(round(length*rate)):
            t=j/rate;u=t/length;noise=rng.uniform(-1,1)
            low+=.025*(noise-low)
            cutoff=.08+.30*math.exp(-((t-lead)/.12)**2)
            mid+=cutoff*(noise-mid)
            other+=.19*(rng.uniform(-1,1)-other)
            if click:
                # Dry paper contact, followed by two much softer fibres settling.
                env=math.exp(-t*85)*min(1,t/.0015)
                flutter=sum(math.exp(-((t-c)/.007)**2)*v for c,v in ((.034,.18),(.071,.07)))
                value=(noise-low)*(.25*env+.12*flutter)
                width=.10
            elif impact:
                after=max(0,t-lead);gate=min(1,max(0,(t-lead)/.006))
                body=math.sin(2*math.pi*(72*after+1.5*(1-math.exp(-after*28))))
                value=.28*body*math.exp(-after*14)*gate
                value+=(mid-low)*.65*math.exp(-((t-lead)/.065)**2)
                width=.12
            else:
                # Air sweep with paper flutter, stereo width and a restrained landing.
                attack=math.exp(-((t-lead)/(.10 if t<lead else .17))**2)
                flutter=.78+.22*math.sin(2*math.pi*(21*t+12*t*t))
                value=(mid-low)*1.05*attack*flutter
                value+=low*.18*math.exp(-((t-lead-.035)/.09)**2)
                width=.22*attack
            # Equal-power pan follows the lateral text/card motion; no hard channel jumps.
            pan=.45*math.tanh((t-lead)*7) if not click else 0
            left=math.sqrt((1-pan)/2);right=math.sqrt((1+pan)/2)
            side=other*width*(math.sin(math.pi*u)**2)
            edge=min(1,t/.003,(length-t)/.015)
            pos=round(start*rate)+j
            if 0<=pos<count:
                volume=project.sfx_volume*edge
                samples[2*pos]+=(value*left+side)*volume
                samples[2*pos+1]+=(value*right-side)*volume
    pcm=array('h',(round(max(-.95,min(.95,v))*32767) for v in samples))
    import sys
    if sys.byteorder!='little':pcm.byteswap()
    with wave.open(str(output),'wb') as out:
        out.setparams((2,2,rate,0,'NONE','not compressed'))
        out.writeframes(pcm.tobytes())
    return True
