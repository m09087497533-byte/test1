"""Choose and assign scene media from local assets and available search sources."""
import json
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import image_search, stock_video
from .media import ASSETS, DATA
from .visual_fallback import text_scene
from .narration import has_stem
from .models import Project
from .network import connection_error

ROOT = DATA / 'auto-media'
ROOT.mkdir(exist_ok=True)


def tokens(text):
    return {word[:6] for word in re.findall(r'[a-zа-яё]{3,}', text.lower())
            if word not in image_search.STOP and word not in {'jpg','jpeg','png','mp4','file','image','video','old','ancient','historical','illuminated','person','human','photo','picture','landscape','footage'}}


def topic_words(text):
    expanded=text
    for stems,query,_ in image_search.CONCEPTS:
        if has_stem(stems,text):expanded+=' '+query
    for stems,query in [(('горы','горах','горная','горный','горам'),'mountain path'),
                        (('путник','поход','тропа','идущий'),'hiking solitary person path'),
                        (('книга','книги','книгой'),'book manuscript'),
                        (('океан','море','морской'),'ocean coastline')]:
        if has_stem(stems,text):expanded+=' '+query
    return tokens(expanded)


def scene_context(project, index):
    context = image_search.scene_query(project, index)
    footage = stock_video.footage_query(project, index)
    scene = project.scenes[index]
    text = (context['basis']+' '+scene.title+' '+scene.caption).lower()
    archive = any(s in text for s in ('рукопис','манускрип','енох','эфиоп','греческ','писание','папирус','летопис','документ','архив'))
    return {**context, 'video_query':footage['query'], 'preferred':'image' if archive else 'video',
            'words':topic_words(context['query']+' '+footage['query']+' '+text)}


def graphic_indices(project):
    """Reserve at most two real spoken emphasis points for full-screen typography."""
    if len(project.scenes)<5:return set()
    candidates=[]
    cursor=0
    for index,scene in enumerate(project.scenes):
        start=cursor/30;cursor+=round(scene.duration*30);end=cursor/30
        spoken=' '.join(c.text for c in project.subtitles if c.start<end and c.end>start)
        events=scene.text_events
        score=max((5 if e.layout in ('grid','number','counter') else 3 if e.treatment in ('neon','chromatic','italic') else 1 for e in events),default=0)
        if re.search(r'(?<!\d)(?:1[5-9]\d{2}|20\d{2})(?!\d)|[«“][^»”]{8,120}[»”]',spoken):score=max(score,4)
        if re.search(r'\b(?:семь|7)\s+признак\w*|\b(?:список|перечень)\b',spoken,re.I):score=max(score,3)
        if score:candidates.append((score,index))
    if not candidates:return set()
    budget=1 if len(project.scenes)<10 else 2
    chosen=[]
    for _,index in sorted(candidates,key=lambda pair:(-pair[0],pair[1])):
        if any(abs(index-old)<2 for old in chosen):continue
        chosen.append(index)
        if len(chosen)>=budget:break
    return set(chosen)


def search_contexts(context, kind):
    """Exact subject first; related period visuals keep variety without changing facts."""
    query=context['query'] if kind=='image' else context['video_query']
    options=[(query,context['concept'])]
    if has_stem(('enoch',),context['query']):
        options += ([('Ethiopian illuminated manuscript','Эфиопская рукопись'),
                     ('ancient manuscript parchment','Старинная рукопись')]
                    if kind=='image' else
                    [('old book pages','Листание старинной книги'),
                     ('ancient manuscript','Старинная рукопись')])
    elif has_stem(('ethiop',),query):
        options += [('Ethiopic manuscript','Эфиопская рукопись'),('Ethiopia manuscript','Эфиопская рукопись')]
    elif has_stem(('greek',),query):
        options += [('Greek manuscript codex','Греческая рукопись')]
    result=[]
    for phrase,concept in dict.fromkeys(options):
        variant={**context,'query':phrase,'story_query':context['query'],'concept':concept,'words':topic_words(phrase+' '+context['basis'])}
        result.append(variant)
    return result


def preferred_kinds(context, mode, index):
    if mode == 'photos': return ['image']
    if mode == 'videos': return ['video']
    # In mixed mode, seek real motion on occasional beats even in archival stories.
    # The relevance check still rejects unrelated stock and then tries photos.
    if index % 3 == 2:return ['video','image']
    return [context['preferred'], 'video' if context['preferred']=='image' else 'image']


def asset_words(asset):
    source = asset.get('provenance',{})
    return topic_words(' '.join(str(x) for x in (asset.get('name',''), source.get('query',''), source.get('description',''))))


def rank_candidate(item, context, duration, order=0, local=False):
    words = asset_words(item) if local else topic_words(str(item.get('title',''))+' '+str(item.get('description','')))
    overlap = len(words & context['words'])
    # Local files need an explicit text match; remote search order supplies a relevance signal.
    score = overlap*2 + (0 if local else 2/(order+1))
    width,height = item.get('width',0),item.get('height',0)
    if width and height:
        score += max(-1,1-abs(width/height-16/9))*.5
    length = item.get('duration',0)
    if item.get('kind')=='video' or item.get('provider'):
        score += .4 if length>=duration else -.4
    return score



def relevant_candidate(item, context, *, local=False):
    """Require described subject evidence; provider rank alone is insufficient.

    Provider queries are metadata, not proof of what an image depicts. Avoid
    choosing the wrong country/manuscript merely because both mention 'book'.
    """
    source=item.get('provenance',{}) if local else {}
    description=' '.join(str(v) for v in (item.get('name',''),item.get('title',''),item.get('description',''),source.get('description','')))
    words=topic_words(description)
    query=context['query'].lower()
    story_query=context.get('story_query','').lower()
    if has_stem(('enoch',),story_query) and not has_stem(('greek','greece'),query) and has_stem(('greek','greece','гречес','греч'),description):return False
    named_book=has_stem(('enoch','енох'),query) and has_stem(('enoch','енох'),description) and has_stem(('book','книг'),description)
    primary=[(('manuscript','parchment'),('manuscript','рукопис','манускрип','papyrus','папирус','parchment','пергамент','codex','кодекс','illuminated')),
             (('mountain','hiking'),('mountain','горы','горах','горн','hiking','поход','тропа')),
             (('map',),('map','карта','картограф')),
             (('candle',),('candle','свеч'))]
    for triggers,required in primary:
        if has_stem(triggers,query) and not has_stem(required,description) and not (triggers[0]=='manuscript' and named_book):return False
    historical=has_stem(('manuscript','parchment','ancient','enoch','ethiop','greek','old book'),query)
    if historical and has_stem(('laptop','notebook','ballpoint','computer','office','homework','ноутбук','тетрад','шариков','компьютер','офис'),description):return False
    if has_stem(('old book',),query) and not has_stem(('old','antique','ancient','vintage','aged','historical','manuscript','parchment','старин','древн','рукопис','пергамент'),description):return False
    entities={'ethiop':('эфиоп','ethiop'),'greek':('гречес','greek'),
              'greece':('грец','греч','greek','greece'),'enoch':('енох','enoch'),
              'egypt':('егип','egypt'),'rome':('рим','rome','roman')}
    for entity,aliases in entities.items():
        if has_stem((entity,),query) and not has_stem(aliases,description):return False
    # The country alone does not turn a church or a skyline into a manuscript.
    subjects=[(('manuscript',),('manuscript','рукопис','манускрип','papyrus','папирус','parchment','пергамент','codex','кодекс','book','книг')),
              (('painting','fresco'),('painting','fresco','миниатюр','икон','живопис','роспис','картина'))]
    for triggers,required in subjects:
        if has_stem(triggers,query) and not has_stem(required,description):return False
    return bool(words & context['words'])


def query_variants(query):
    alternatives={'Book of Enoch manuscript':'Enoch manuscript',
                  'Ethiopian illuminated manuscript':'Ethiopic manuscript',
                  'Greek biblical manuscript':'Greek manuscript',
                  'illuminated manuscript parchment':'illuminated manuscript',
                  'solitary person mountain path':'person hiking mountains',
                  'ancient book':'old book pages'}
    return list(dict.fromkeys([query,alternatives.get(query,query)]))

def asset_identity(asset):
    return asset.get('provenance',{}).get('source_url') or asset.get('source_url') or asset.get('id')


def local_assets():
    items=[]
    for path in sorted(ASSETS.glob('*/meta.json')):
        try:
            item=json.loads(path.read_text())
            if item.get('kind') in ('image','video'):items.append(item)
        except (OSError,ValueError):continue
    return items


def assignment(index,asset,context,origin):
    is_video=asset['kind']=='video'
    # The editor can change the offset after automatic assignment.
    return {'scene_index':index,'asset':asset,'offset':0,
            'reason':f"{'Видео' if is_video else 'Фото'} · {context['concept']} · {origin}",
            'query':context['query']}


def arrange(project, mode, replace, update, cancelled, scene_indices=None, excluded_asset_ids=None):
    library=[a for a in local_assets() if a.get('created_at',0)>=project.library_since]
    excluded=set(excluded_asset_ids or [])
    excluded.update(asset_identity(a) for a in library if a['id'] in excluded)
    targets=set(scene_indices) if scene_indices is not None else set(range(len(project.scenes)))
    used={asset_identity(a) for a in library if any(s.asset_id==a['id'] and (i not in targets or not replace)
                                                    for i,s in enumerate(project.scenes))}
    available=[p for p in ('pexels','pixabay') if stock_video.get_key(p)]
    disabled=set(); cache={}; imported=[]; outcomes=[]; errors=[]; fallbacks=[]; usage={}
    total=len(targets) or 1

    def publish(index,message):
        update({'progress':round(index/total*100),'message':message,'assignments':list(imported),
                'outcomes':list(outcomes),'errors':list(dict.fromkeys(errors)), 'fallbacks':list(fallbacks)})

    for index,scene in enumerate(project.scenes):
        if index not in targets:continue
        if cancelled():break
        if scene.template in ('quote','thesis') and not scene.automatic_text:
            outcomes.append({'scene_index':index,'status':'skipped','reason':'Текстовая сцена использует собственный фон.'})
            publish(len(outcomes),f'Сцена {index+1}: текстовый фон');continue
        if scene.asset_id and not replace:
            outcomes.append({'scene_index':index,'status':'kept','reason':'Сохранён назначенный материал.'})
            publish(len(outcomes),f'Сцена {index+1}: материал сохранён');continue
        try:context=scene_context(project,index)
        except ValueError as exc:
            if project.director_version>=9:
                fallback=text_scene(project,index)
                fallbacks.append({'scene_index':index,'scene':fallback.model_dump(),'reason':fallback.media_reason})
                outcomes.append({'scene_index':index,'status':'text','reason':fallback.media_reason})
            else:outcomes.append({'scene_index':index,'status':'missing','reason':str(exc)})
            publish(len(outcomes),f'Сцена {index+1}: нужен текст для поиска');continue
        publish(len(outcomes),f'Сцена {index+1}: {context["concept"]}')
        if context.get('text_only'):
            fallback=text_scene(project,index)
            fallbacks.append({'scene_index':index,'scene':fallback.model_dump(),'reason':fallback.media_reason})
            outcomes.append({'scene_index':index,'status':'text','reason':fallback.media_reason})
            publish(len(outcomes),f'Сцена {index+1}: текстовая композиция');continue
        chosen=None
        kinds=preferred_kinds(context,mode,index)
        for kind in kinds:
            for variant in search_contexts(context,kind):
                if cancelled():break
                local=[a for a in library if a['kind']==kind and a['id'] not in excluded and
                       asset_identity(a) not in excluded and asset_identity(a) not in used and
                       relevant_candidate(a,variant,local=True)]
                if local:
                    best=max(local,key=lambda a:rank_candidate(a,variant,scene.duration,local=True))
                    chosen=assignment(index,best,variant,'из библиотеки')
                    break
                sources=['commons'] if kind=='image' else available
                candidates=[]
                for provider in sources:
                    if cancelled():break
                    if provider in disabled:continue
                    for phrase in query_variants(variant['query']):
                        key=(provider,phrase)
                        if key not in cache:
                            try:
                                cache[key]=image_search.search_images(phrase) if provider=='commons' else stock_video.search_videos(provider,phrase)
                            except (ValueError,OSError) as exc:
                                message=connection_error(exc,'Wikimedia Commons') if isinstance(exc,OSError) else str(exc)
                                errors.append(message)
                                disabled.add(provider);cache[key]=[]
                        for order,item in enumerate(cache[key]):
                            if asset_identity(item) not in used and asset_identity(item) not in excluded and relevant_candidate(item,variant):
                                candidates.append((rank_candidate(item,variant,scene.duration,order),provider,item))
                        if candidates or provider in disabled or cancelled():break
                for _,provider,item in sorted(candidates,key=lambda c:c[0],reverse=True)[:3]:
                    if cancelled():break
                    try:
                        asset=image_search.import_image(item['token']) if provider=='commons' else stock_video.import_video(item['token'])
                        if cancelled():break
                        chosen=assignment(index,asset,variant,'Wikimedia' if provider=='commons' else provider.title())
                        library.append(asset);break
                    except (ValueError,OSError) as exc:
                        errors.append(connection_error(exc,'Загрузка материала') if isinstance(exc,OSError) else str(exc))
                    except Exception:
                        errors.append('Не удалось прочитать один из найденных материалов. Пробуем следующий.')
                if chosen:break
            if chosen or cancelled():break
        if cancelled():break
        if not chosen and project.director_version>=9:
            # Uniqueness is a preference, never a reason to leave a hole in a film.
            for kind in kinds:
                for variant in search_contexts(context,kind):
                    reusable=[a for a in library if a['kind']==kind and a['id'] not in excluded and
                              asset_identity(a) not in excluded and usage.get(asset_identity(a),0)<2 and
                              relevant_candidate(a,variant,local=True)]
                    if reusable:
                        asset=max(reusable,key=lambda a:rank_candidate(a,variant,scene.duration,local=True)-usage.get(asset_identity(a),0)*2)
                        chosen=assignment(index,asset,variant,'повтор подходящего материала')
                        break
                if chosen:break
        if not chosen and project.director_version>=9:
            fallback=text_scene(project,index)
            fallbacks.append({'scene_index':index,'scene':fallback.model_dump(),'reason':fallback.media_reason})
            outcomes.append({'scene_index':index,'status':'text','reason':fallback.media_reason})
        elif chosen:
            chosen['restore_visual']=scene.automatic_text
            imported.append(chosen);used.add(asset_identity(chosen['asset']))
            identity=asset_identity(chosen['asset']);usage[identity]=usage.get(identity,0)+1
            outcomes.append({'scene_index':index,'status':'assigned','reason':chosen['reason']})
        else:
            reason='Не найден материал с подтверждением темы в описании. Случайный кадр не назначен; повторите автоподбор позже.'
            if mode=='videos' and not available:reason='Для поиска видео подключите Pexels или Pixabay либо загрузите подходящий футаж в библиотеку.'
            outcomes.append({'scene_index':index,'status':'missing','reason':reason})
        publish(len(outcomes),f'Обработано {len(outcomes)} из {total} сцен')
    return {'assignments':imported,'outcomes':outcomes,'fallbacks':fallbacks,'errors':list(dict.fromkeys(errors))}


class ArrangementJobs:
    def __init__(self,root=ROOT):
        self.root=Path(root);self.root.mkdir(exist_ok=True)
        self.lock=threading.Lock();self.pool=ThreadPoolExecutor(max_workers=1)
        self.states={};self.cancellations={}
        for file in self.root.glob('*/status.json'):
            try:
                state=json.loads(file.read_text())
                if state['status'] in ('queued','running','cancelling'):
                    state.update(status='interrupted',message='Подбор прерван перезапуском. Уже найденные материалы доступны; запустите подбор для оставшихся сцен.')
                    file.write_text(json.dumps(state,ensure_ascii=False))
                self.states[file.parent.name]=state
            except (OSError,ValueError,KeyError):continue

    def _write(self,identifier,state):
        folder=self.root/identifier
        temp=folder/'status.tmp';temp.write_text(json.dumps(state,ensure_ascii=False));temp.replace(folder/'status.json')

    def start(self,project,mode,replace,scene_indices=None,excluded_asset_ids=None):
        with self.lock:
            if any(s['status'] in ('queued','running','cancelling') for s in self.states.values()):
                raise ValueError('Дождитесь текущего подбора или остановите его.')
            identifier=uuid.uuid4().hex;(self.root/identifier).mkdir()
            (self.root/identifier/'project.json').write_text(project.model_dump_json(indent=2))
            state={'id':identifier,'status':'queued','progress':0,'message':'Подготовка автоматического подбора',
                   'assignments':[],'outcomes':[],'errors':[]}
            self.states[identifier]=state;self.cancellations[identifier]=threading.Event()
            self._write(identifier,state)
        self.pool.submit(self._run,identifier,project,mode,replace,scene_indices,excluded_asset_ids)
        return json.loads(json.dumps(state))

    def _run(self,identifier,project,mode,replace,scene_indices=None,excluded_asset_ids=None):
        event=self.cancellations[identifier]
        def update(changes):
            with self.lock:
                state=self.states[identifier]
                state.update(changes,status='cancelling' if event.is_set() else 'running')
                self._write(identifier,state)
        try:
            result=arrange(project,mode,replace,update,event.is_set,scene_indices,excluded_asset_ids)
            with self.lock:
                state=self.states[identifier]
                state.update(result,status='cancelled' if event.is_set() else 'done',progress=state['progress'] if event.is_set() else 100,
                             message='Подбор остановлен' if event.is_set() else f'Назначено материалов: {len(result["assignments"])}')
                self._write(identifier,state)
        except Exception:
            with self.lock:
                state=self.states[identifier];state.update(status='error',message='Подбор прерван из-за ошибки. Уже найденные материалы сохранены.')
                self._write(identifier,state)

    def get(self,identifier):
        with self.lock:
            if identifier not in self.states:raise KeyError(identifier)
            return json.loads(json.dumps(self.states[identifier]))

    def cancel(self,identifier):
        with self.lock:
            if identifier not in self.states:raise KeyError(identifier)
            if self.states[identifier]['status'] in ('queued','running','cancelling'):
                self.cancellations[identifier].set()
                self.states[identifier].update(status='cancelling',message='Останавливаем после текущего запроса…')
                self._write(identifier,self.states[identifier])
        return self.get(identifier)
