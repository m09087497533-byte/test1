"""Frame-aligned transitions and original synthesized transition sound effects."""
import math
import random
import wave
from array import array
from pathlib import Path

from .media import run
from .models import Project, frame_count, total_duration

TRANSITIONS = {'dissolve': 'fade', 'slide': 'smoothleft', 'flash': 'fadewhite',
               'blur': 'hblur', 'wipe': 'wipeleft'}
CYCLE = ('dissolve', 'slide', 'flash', 'blur', 'wipe')


def boundary_style(project: Project, index: int) -> str:
    override = project.scenes[index].transition_out
    if override != 'inherit':
        return override
    if project.transition == 'mixed':
        return CYCLE[index % len(CYCLE)]
    return project.transition if project.transition in TRANSITIONS else 'cut'


def transition_frames(project: Project, index: int) -> int:
    if index >= len(project.scenes)-1 or boundary_style(project, index) == 'cut':
        return 0
    # Leave readable time even in a one-second scene.
    return min(12, frame_count(project.scenes[index+1])//3)


def encode_segment(args: list[str], graph: str, frames: int, output: Path):
    run(['ffmpeg', '-v', 'error', '-y', '-filter_complex_threads', '1', *args,
         '-filter_complex', graph, '-map', '[out]', '-an', '-frames:v', str(frames),
         '-r', '30', '-fps_mode', 'cfr', '-c:v', 'libx264', '-preset', 'veryfast',
         '-crf', '20', '-threads', '2', '-video_track_timescale', '15360', str(output)], timeout=600)


def assemble(project: Project, pieces: list[Path], folder: Path, progress) -> Path:
    """Render only two adjacent handles at a time, avoiding an unbounded xfade graph.

    Each outgoing scene has a spare handle after its nominal end. Blend it with
    the first frames of the next scene, then consume those frames from its core.
    Result: no accumulated timeline shortening; SRT and voice remain absolute.
    """
    segments = []
    for index, (scene, piece) in enumerate(zip(project.scenes, pieces)):
        incoming = transition_frames(project, index-1) if index else 0
        outgoing = transition_frames(project, index)
        frames = frame_count(scene)
        if not incoming and not outgoing:
            segments.append(piece)
        else:
            core = folder / f'core-{index:03d}.mp4'
            graph = f'[0:v]trim=start_frame={incoming}:end_frame={frames},setpts=N/(30*TB),format=yuv420p[out]'
            encode_segment(['-i', str(piece)], graph, frames-incoming, core)
            segments.append(core)
        if outgoing:
            progress(73+int(index/len(pieces)*13), f'Переход {index+1}: {boundary_style(project,index)}')
            transition = folder / f'transition-{index:03d}.mp4'
            graph = (f'[0:v]trim=start_frame={frames}:end_frame={frames+outgoing},setpts=N/(30*TB),fps=30,settb=1/30[a];'
                     f'[1:v]trim=end_frame={outgoing},setpts=N/(30*TB),fps=30,settb=1/30[b];'
                     f'[a][b]xfade=transition={TRANSITIONS[boundary_style(project,index)]}:duration={outgoing/30}:offset=0,'
                     'format=yuv420p[out]')
            encode_segment(['-i', str(piece), '-i', str(pieces[index+1])], graph, outgoing, transition)
            segments.append(transition)
    concat = folder / 'concat.txt'
    concat.write_text(''.join(f"file '{p.name}'\n" for p in segments))
    video = folder / 'picture.mp4'
    run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '1', '-i', str(concat), '-c', 'copy', str(video)])
    return video


def synthesize_sfx(project: Project, output: Path) -> bool:
    if project.sfx_volume == 0:
        return False
    rate = 48000
    samples = array('f', [0.0])*math.ceil(total_duration(project)*rate)
    cursor = 0.0
    events = 0
    for index, scene in enumerate(project.scenes[:-1]):
        cursor += frame_count(scene)/30
        length = transition_frames(project, index)
        if not length or not project.transition_sounds:
            continue
        events += 1
        style = boundary_style(project, index)
        rng = random.Random(2100+index)
        # Peak follows the visual midpoint. Original noises, not reference audio.
        peak = cursor + length/60
        start = peak-.24
        low, band = 0.0, 0.0
        for j in range(int(.76*rate)):
            t = j/rate
            noise = rng.uniform(-1, 1)
            low += .06*(noise-low)
            band += (.12+.30*math.sin(math.pi*min(1,t/.76)))*(noise-band)
            sweep = (band-low)*math.exp(-((t-.24)/.15)**2)
            if style == 'flash':
                impact = math.sin(2*math.pi*(85*t-22*t*t))*math.exp(-max(0,t-.24)*19) if t >= .24 else 0
                value = .4*sweep + .30*impact
            elif style == 'wipe':
                value = .6*sweep*(.65+.35*math.sin(2*math.pi*36*t))
            elif style == 'slide':
                value = 1.1*sweep
            elif style == 'blur':
                value = .75*sweep + .1*low*math.sin(math.pi*t/.76)**2
            else:
                value = .4*sweep
            position = round(start*rate)+j
            if 0 <= position < len(samples):
                samples[position] += value*project.sfx_volume
    cursor = 0.0
    for index, scene in enumerate(project.scenes):
        if scene.title_sound != 'none' and (scene.title or scene.caption):
            events += 1
            start = round((cursor + round(scene.title_delay*30)/30)*rate)
            rng = random.Random(7200+index)
            smooth = 0.0
            for j in range(int(.35*rate)):
                t = j/rate
                noise = rng.uniform(-1,1)
                smooth += .14*(noise-smooth)
                if scene.title_sound == 'click':
                    value = .32*noise*math.exp(-t*110)*min(1,t/.001)
                elif scene.title_sound == 'impact':
                    value = .40*math.sin(2*math.pi*(100*t-65*t*t))*math.exp(-t*17)*min(1,t/.005)
                else:
                    value = smooth*.8*math.sin(math.pi*t/.35)**2
                if start+j < len(samples):
                    samples[start+j] += value*project.sfx_volume
        cursor += frame_count(scene)/30
    if not events:
        return False
    pcm = array('h', (round(max(-.95,min(.95,v))*32767) for v in samples))
    import sys
    if sys.byteorder != 'little':
        pcm.byteswap()
    with wave.open(str(output), 'wb') as out:
        out.setparams((1,2,rate,0,'NONE','not compressed'))
        out.writeframes(pcm.tobytes())
    return True
