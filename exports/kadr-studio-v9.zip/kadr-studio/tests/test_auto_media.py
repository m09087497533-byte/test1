import json
import tempfile
import time
import subprocess
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image
from fastapi.testclient import TestClient
import studio.auto_media as auto
from studio.app import app
from studio.models import Project,Scene,Subtitle
from studio.render import render
from studio.media import probe
from studio.stock_video import StockError


def example_project():
    return Project(scenes=[Scene(duration=1),Scene(duration=1)],transition='cut',
                   subtitles=[Subtitle(start=0,end=.95,text='Глава сохранилась только в Эфиопии.'),
                              Subtitle(start=1,end=1.95,text='Худшие годы жизни — это испытание.')])


def asset(identifier,kind,name,query='',source=None):
    return {'id':identifier,'kind':kind,'name':name,'duration':2 if kind=='video' else 0,'file':'source' if kind=='video' else 'image.jpg',
            'has_audio':False,'provenance':{'query':query,'source_url':source or 'https://example.test/'+identifier,
                                          'author':'Test author','license':'Test fixture','license_url':'https://example.test/license'}}

class AutomaticMediaTest(unittest.TestCase):
    def test_uses_subtitles_to_assign_photo_and_video_from_library(self):
        photo=asset('a'*32,'image','Ethiopian manuscript','Ethiopian illuminated manuscript')
        video=asset('b'*32,'video','Hiking mountain path','solitary person mountain path')
        updates=[]
        with patch.object(auto,'local_assets',return_value=[video,photo]),patch.object(auto.stock_video,'get_key',return_value=''),patch.object(auto.image_search,'search_images') as remote:
            result=auto.arrange(example_project(),'mixed',False,updates.append,lambda:False)
        self.assertEqual([a['asset']['kind'] for a in result['assignments']],['image','video'])
        self.assertEqual([a['scene_index'] for a in result['assignments']],[0,1])
        self.assertIn('Эфиопская',result['assignments'][0]['reason'])
        remote.assert_not_called();self.assertEqual(updates[-1]['progress'],100)

    def test_russian_filenames_match_visual_topics(self):
        photo=asset('a'*32,'image','Эфиопская рукопись.jpg')
        video=asset('b'*32,'video','Путник в горах.mp4')
        with patch.object(auto,'local_assets',return_value=[photo,video]),patch.object(auto.stock_video,'get_key',return_value=''):
            result=auto.arrange(example_project(),'mixed',False,lambda x:None,lambda:False)
        self.assertEqual([a['asset']['id'] for a in result['assignments']],['a'*32,'b'*32])

    def test_keeps_assigned_media_and_text_backgrounds(self):
        p=Project(scenes=[Scene(asset_id='a'*32,title='Енох'),Scene(template='quote',title='Цитата')])
        with patch.object(auto,'local_assets',return_value=[]),patch.object(auto.stock_video,'get_key',return_value=''),patch.object(auto.image_search,'search_images') as remote:
            result=auto.arrange(p,'mixed',False,lambda x:None,lambda:False)
        self.assertFalse(result['assignments']);self.assertEqual([o['status'] for o in result['outcomes']],['kept','skipped']);remote.assert_not_called()

    def test_downloads_video_then_falls_back_to_photo_without_repeated_failed_source(self):
        p=Project(scenes=[Scene(duration=2,title='Худшие годы'),Scene(duration=2,title='Древняя книга Еноха')])
        video={'token':'1'*32,'provider':'pexels','title':'hiking mountains','source_url':'https://example.test/hike','duration':5,'width':1920,'height':1080}
        photo={'token':'2'*32,'title':'Enoch manuscript','source_url':'https://example.test/book','width':1200,'height':800}
        def search(provider,query):
            if 'book' in query:raise StockError('Сервис недоступен.')
            return [video]
        with patch.object(auto,'local_assets',return_value=[]),patch.object(auto.stock_video,'get_key',return_value='test-key'),\
             patch.object(auto.stock_video,'search_videos',side_effect=search),\
             patch.object(auto.stock_video,'import_video',return_value=asset('a'*32,'video','hike',source=video['source_url'])),\
             patch.object(auto.image_search,'search_images',return_value=[photo]),\
             patch.object(auto.image_search,'import_image',return_value=asset('b'*32,'image','book',source=photo['source_url'])):
            result=auto.arrange(p,'mixed',False,lambda x:None,lambda:False)
        self.assertEqual([a['asset']['kind'] for a in result['assignments']],['video','image'])

    def test_unrelated_local_file_is_not_assigned_and_duplicates_are_not_used(self):
        photo=asset('a'*32,'image','Ethiopian manuscript','Ethiopian illuminated manuscript')
        unrelated=asset('b'*32,'image','ocean boat waves','ocean')
        p=Project(scenes=[Scene(title='Эфиопия'),Scene(title='Эфиопия')])
        with patch.object(auto,'local_assets',return_value=[photo,unrelated]),patch.object(auto.stock_video,'get_key',return_value=''),patch.object(auto.image_search,'search_images',return_value=[]):
            result=auto.arrange(p,'photos',False,lambda x:None,lambda:False)
        self.assertEqual(len(result['assignments']),1);self.assertEqual(result['outcomes'][1]['status'],'missing')

    def test_mode_and_missing_credentials_are_respected(self):
        p=Project(scenes=[Scene(title='Эфиопия')])
        with patch.object(auto,'local_assets',return_value=[]),patch.object(auto.stock_video,'get_key',return_value=''),patch.object(auto.image_search,'search_images') as photo:
            result=auto.arrange(p,'videos',False,lambda x:None,lambda:False)
        self.assertEqual(len(result['assignments']),0);self.assertIn('Pexels',result['outcomes'][0]['reason']);photo.assert_not_called()

    def test_failed_source_is_not_retried_for_every_scene(self):
        with patch.object(auto,'local_assets',return_value=[]),patch.object(auto.stock_video,'get_key',return_value=''),patch.object(auto.image_search,'search_images',side_effect=OSError('network')) as search:
            result=auto.arrange(example_project(),'photos',False,lambda x:None,lambda:False)
        self.assertEqual(search.call_count,1);self.assertEqual(len(result['outcomes']),2);self.assertEqual(len(result['errors']),1)

    def test_cancel_keeps_already_found_materials(self):
        photos=[asset('a'*32,'image','Ethiopian manuscript'),asset('b'*32,'video','mountain path')]
        cancelled=False
        def update(state):
            nonlocal cancelled
            if state['assignments']:cancelled=True
        with patch.object(auto,'local_assets',return_value=photos),patch.object(auto.stock_video,'get_key',return_value=''):
            result=auto.arrange(example_project(),'mixed',False,update,lambda:cancelled)
        self.assertEqual(len(result['assignments']),1);self.assertEqual(len(result['outcomes']),1)

    def test_real_job_applies_to_renderable_media_and_persists(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);assets=root/'assets';assets.mkdir()
            photo=asset('a'*32,'image','Ethiopian manuscript','Ethiopian illuminated manuscript')
            video=asset('b'*32,'video','mountain path hiking','solitary person mountain path')
            for item in [photo,video]:
                folder=assets/item['id'];folder.mkdir();(folder/'meta.json').write_text(json.dumps(item))
                Image.new('RGB',(640,360),'#386448').save(folder/'thumb.jpg')
                if item['kind']=='image':Image.new('RGB',(800,600),'#c7bb94').save(folder/'image.jpg')
                else:subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','testsrc2=size=320x180:rate=30','-t','2','-c:v','libx264','-threads','2','-f','mp4',str(folder/'source')],check=True)
            manager=auto.ArrangementJobs(root/'jobs')
            with patch('studio.app.arrangement_jobs',manager),patch.object(auto,'ASSETS',assets),patch.object(auto.stock_video,'get_key',return_value=''),TestClient(app) as client:
                response=client.post('/api/auto-media',json={'project':example_project().model_dump(),'mode':'mixed'})
                self.assertEqual(response.status_code,202,response.text);identifier=response.json()['id']
                deadline=time.monotonic()+10
                while time.monotonic()<deadline:
                    state=client.get('/api/auto-media/'+identifier).json()
                    if state['status']=='done':break
                    time.sleep(.02)
                self.assertEqual(state['status'],'done');self.assertEqual(len(state['assignments']),2)
            manager.pool.shutdown(wait=True)
            restored=auto.ArrangementJobs(root/'jobs');self.assertEqual(restored.get(identifier)['status'],'done');restored.pool.shutdown()
            project=example_project()
            for item in state['assignments']:project.scenes[item['scene_index']].asset_id=item['asset']['id']
            out=root/'render';out.mkdir()
            with patch('studio.media.ASSETS',assets):film=render(project,out,lambda *a:None)
            self.assertEqual(int(probe(film)['streams'][0]['nb_frames']),60)
