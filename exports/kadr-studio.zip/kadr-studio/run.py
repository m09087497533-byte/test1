"""Run the local studio and open its UI after the server is ready."""
import argparse
import threading
import time
import urllib.request
import webbrowser


def main():
    parser = argparse.ArgumentParser(description='Кадр — локальная видеомастерская')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    import shutil
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        parser.exit(1, 'Нужен FFmpeg. Инструкции установки — в README.md.\n')
    try:
        import uvicorn
    except ImportError:
        parser.exit(1, 'Сначала установи зависимости: python3 -m pip install -r requirements.txt\n')
    url = f'http://127.0.0.1:{args.port}'
    if not args.no_browser:
        def open_when_ready():
            for _ in range(100):
                try:
                    with urllib.request.urlopen(url+'/api/health', timeout=1) as response:
                        if response.status == 200:
                            webbrowser.open(url)
                            return
                except OSError:
                    time.sleep(.1)
        threading.Thread(target=open_when_ready, daemon=True).start()
    uvicorn.run('studio.app:app', host='127.0.0.1', port=args.port)


if __name__ == '__main__':
    main()
