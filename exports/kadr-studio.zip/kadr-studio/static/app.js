'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const labels = {cinema: 'Кино', archive: 'Архив', statement: 'Акцент', quote: 'Цитата', thesis:'Тезис'};
let project, assets = [], selected = 0, previewUrl, previewTimer, previewVersion = 0, toastTimer, polling = false;
const storageKey = 'kadr-project-v1';
const seconds = (n) => `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(Math.floor(n % 60)).padStart(2, '0')}`;
const duration = () => project.scenes.reduce((sum, s) => sum + Math.round(s.duration * 30) / 30, 0);
const sceneStart = (index) => project.scenes.slice(0, index).reduce((sum, s) => sum + Math.round(s.duration * 30) / 30, 0);
const media = (id) => assets.find(a => a.id === id);

function toast(message, error = false) {
  clearTimeout(toastTimer);
  $('#toast').textContent = message;
  $('#toast').className = error ? 'error' : '';
  toastTimer = setTimeout(() => $('#toast').classList.add('hidden'), error ? 10000 : 5000);
}
function errorText(data) {
  if (typeof data.detail === 'string') return data.detail;
  if (Array.isArray(data.detail)) return data.detail.map(e => `${e.loc.slice(1).join('.') || 'Проект'}: ${e.msg}`).join('; ');
  return 'Не удалось выполнить запрос';
}
async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let data;
    try { data = await response.json(); } catch { data = {detail: `Ошибка сервера (${response.status})`}; }
    throw new Error(errorText(data));
  }
  return response;
}
const jsonPost = (value) => ({method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(value)});
function on(selector, event, handler) {
  $(selector).addEventListener(event, async (e) => {
    try { await handler(e); } catch (error) { toast(error.message, true); }
  });
}
function save() {
  try { localStorage.setItem(storageKey, JSON.stringify(project)); $('#save-state').textContent = 'Сохранено в браузере'; }
  catch { $('#save-state').textContent = 'Скачай проект для сохранения'; }
}
function refresh() {
  save();
  paintTimeline();
  paintInspector();
  paintAssets();
  paintAudio();
  paintTranscript();
  queuePreview();
}

function paintTimeline() {
  $('#project-name').value = project.name;
  $('#total-time').textContent = seconds(duration());
  $('#scene-count').textContent = `${project.scenes.length} сцен · ${project.resolution} · 30 fps`;
  $('#timeline').replaceChildren();
  project.scenes.forEach((s, index) => {
    const button = document.createElement('button');
    button.className = `scene-card ${index === selected ? 'selected' : ''}`;
    button.setAttribute('aria-label', `Сцена ${index + 1}: ${s.title || labels[s.template]}`);
    button.setAttribute('aria-pressed', index === selected ? 'true' : 'false');
    const art = document.createElement('div'); art.className = `card-art ${s.template}-art`;
    if (s.asset_id && s.template !== 'quote') {
      const image = document.createElement('img'); image.src = `/api/assets/${s.asset_id}/thumb`; image.alt = ''; art.append(image);
    }
    const title = document.createElement('span'); title.textContent = s.title || labels[s.template]; art.append(title);
    const meta = document.createElement('small');
    const n = document.createElement('span'); n.textContent = `${String(index+1).padStart(2, '0')} / ${labels[s.template]}`;
    const d = document.createElement('span'); d.textContent = `${Number(s.duration.toFixed(1))} с`; meta.append(n, d);
    button.append(art, meta);
    button.addEventListener('click', () => { selected = index; refresh(); });
    $('#timeline').append(button);
  });
}
function paintInspector() {
  const s = project.scenes[selected];
  $('#inspector-title').textContent = `Сцена ${String(selected + 1).padStart(2, '0')}`;
  $('#scene-counter').textContent = `${String(selected + 1).padStart(2, '0')} / ${String(project.scenes.length).padStart(2, '0')}`;
  $('#scene-title').value = s.title;
  $('#scene-caption').value = s.caption;
  $('#scene-duration').value = Number(s.duration.toFixed(3));
  $('#scene-offset').value = s.offset;
  $('#scene-offset').disabled = media(s.asset_id)?.kind !== 'video';
  $('#scene-motion').checked = s.motion;
  $('#scene-motion').disabled = s.template === 'quote' || media(s.asset_id)?.kind === 'video';
  $('#transition').value = project.transition;
  $('#scene-transition').value = s.transition_out || 'inherit';
  $('#motion-style').value = s.motion_style || 'push';
  $('#motion-style').disabled = !s.motion || s.template === 'quote' || media(s.asset_id)?.kind === 'video';
  $('#transition-sounds').checked = !!project.transition_sounds;
  $('#animate-titles').checked = !!project.animate_titles;
  $('#sfx-volume').value = Math.round((project.sfx_volume ?? .35)*100);
  $('#sfx-value').value = `${$('#sfx-volume').value}%`;
  $('#resolution').value = project.resolution;
  $$('[data-template]').forEach(b => { b.classList.toggle('active', b.dataset.template === s.template); b.setAttribute('aria-pressed', String(b.dataset.template === s.template)); });
  $('#clear-asset').classList.toggle('hidden', !s.asset_id);
  $('#move-left').disabled = selected === 0;
  $('#move-right').disabled = selected === project.scenes.length - 1;
  $('#delete-scene').disabled = project.scenes.length === 1;
  $('#scene-source').textContent = s.template === 'quote' ? 'Карточка цитаты' : (media(s.asset_id)?.name || 'Демонстрационный фон · добавь свой материал');
  $('#scene-time').textContent = `${seconds(sceneStart(selected))} — ${seconds(sceneStart(selected) + s.duration)}`;
}
function paintAssets() {
  $('#asset-grid').replaceChildren();
  const visuals = assets.filter(a => a.kind !== 'audio');
  $('#asset-empty').classList.toggle('hidden', visuals.length > 0);
  for (const a of visuals) {
    const button = document.createElement('button'); button.className = `asset ${project.scenes[selected].asset_id === a.id ? 'active' : ''}`;
    button.title = a.name;
    const img = document.createElement('img'); img.src = `/api/assets/${a.id}/thumb`; img.alt = a.name;
    const name = document.createElement('span'); name.textContent = `${a.kind === 'video' ? '▶ ' : ''}${a.name}`;
    button.append(img, name);
    button.addEventListener('click', () => {
      if (project.scenes[selected].template === 'quote') toast('Материал сохранён в сцене. Шаблон «Цитата» использует бумажный фон.');
      project.scenes[selected].asset_id = a.id; project.scenes[selected].offset = 0; refresh();
    });
    $('#asset-grid').append(button);
  }
}
function paintAudio() {
  const voice = media(project.voice_id), music = media(project.music_id);
  $('#voice-info').classList.toggle('hidden', !voice);
  if (voice) {
    $('#voice-info>span').textContent = `${voice.name} · ${seconds(voice.duration)}`;
    const url = `/api/assets/${voice.id}/file`;
    if ($('#voice-info audio').getAttribute('src') !== url) $('#voice-info audio').src = url;
  } else { $('#voice-info audio').removeAttribute('src'); }
  $('#music-info').textContent = music ? `${music.name} · ${seconds(music.duration)}` : 'Необязательно. Озвучка звучит поверх музыки.';
  $('#remove-music').classList.toggle('hidden', !music);
  $('#music-volume').value = Math.round(project.music_volume * 100);
  $('#volume-value').value = `${Math.round(project.music_volume * 100)}%`;
  const count = project.subtitles.length;
  $('#subtitle-info').textContent = count ? `${count} фраз · до ${seconds(Math.max(...project.subtitles.map(c => c.end)))}. Таймкоды фиксированы; изменение сцен не сдвигает субтитры.` : 'Таймкоды остаются такими, как в файле.';
}
function paintTranscript() {
  $('#cue-count').textContent = `${project.subtitles.length} фраз`;
  $('#cue-list').replaceChildren();
  project.subtitles.forEach(cue => {
    const button = document.createElement('button'); button.className = 'cue';
    const time = document.createElement('time'); time.textContent = seconds(cue.start);
    const text = document.createElement('span'); text.textContent = cue.text;
    button.append(time, text);
    button.addEventListener('click', () => {
      let time = 0;
      const index = project.scenes.findIndex(s => { time += s.duration; return time > cue.start; });
      selected = index < 0 ? project.scenes.length-1 : index; refresh();
      // Show the selected cue; a static composition is not a real-time player.
      $('#preview-subtitle').textContent = cue.text;
    });
    $('#cue-list').append(button);
  });
}
function queuePreview() {
  clearTimeout(previewTimer);
  const requestId = ++previewVersion;
  const s = structuredClone(project.scenes[selected]);
  const start = sceneStart(selected);
  const cue = project.subtitles.find(c => c.start <= start + .1 && c.end > start);
  $('#preview-subtitle').textContent = cue?.text || '';
  previewTimer = setTimeout(async () => {
    $('#preview-loading').classList.remove('hidden');
    try {
      const response = await api('/api/preview', jsonPost(s));
      const blob = await response.blob();
      if (requestId !== previewVersion) return;
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = URL.createObjectURL(blob); $('#scene-preview').src = previewUrl;
    } catch (e) { if (requestId === previewVersion) toast(e.message, true); }
    finally { if (requestId === previewVersion) $('#preview-loading').classList.add('hidden'); }
  }, 220);
}
function changed() { save(); paintTimeline(); queuePreview(); }
async function uploadOne(file) {
  if (file.size > 256 * 1024 * 1024) throw new Error('Максимальный размер файла — 256 МБ');
  const form = new FormData(); form.append('file', file);
  toast(`Загружаем ${file.name}…`);
  const asset = await (await api('/api/assets', {method: 'POST', body: form})).json();
  assets.push(asset); return asset;
}
for (const kind of ['voice', 'music', 'visual', 'srt']) {
  on(`#upload-${kind}`, 'click', () => $(`#file-${kind}`).click());
}
on('#upload-visual-empty', 'click', () => $('#file-visual').click());
for (const kind of ['voice', 'music']) {
  on(`#file-${kind}`, 'change', async (e) => {
    const file = e.target.files[0]; e.target.value = ''; if (!file) return;
    const asset = await uploadOne(file);
    if (!asset.has_audio) { paintAssets(); throw new Error('В этом файле нет звуковой дорожки'); }
    project[`${kind}_id`] = asset.id; refresh();
    toast(kind === 'voice' ? 'Озвучка добавлена. Теперь загрузи SRT или VTT, чтобы построить монтаж по таймкодам.' : 'Музыка добавлена');
  });
}
on('#file-visual', 'change', async (e) => {
  const files = [...e.target.files]; e.target.value = '';
  for (const file of files) {
    const asset = await uploadOne(file);
    if (asset.kind === 'audio') { toast('Аудиофайл добавлен в библиотеку, но для сцены нужно изображение или видео.', true); continue; }
    if (files.length === 1) { project.scenes[selected].asset_id = asset.id; project.scenes[selected].offset = 0; }
    refresh();
  }
  if (files.length) toast('Материалы добавлены. Нажми на изображение, чтобы назначить его выбранной сцене.');
});
on('#file-srt', 'change', async (e) => {
  const file = e.target.files[0]; e.target.value = ''; if (!file) return;
  if (!confirm('Построить сцены по этим субтитрам? Текущий монтаж будет заменён. Озвучка и библиотека материалов сохранятся.')) return;
  const form = new FormData(); form.append('file', file); if (project.voice_id) form.append('voice_id', project.voice_id);
  const data = await (await api('/api/subtitles', {method: 'POST', body: form})).json();
  project.scenes = data.scenes; project.subtitles = data.subtitles; selected = 0; refresh();
  toast(`Монтаж создан: ${data.scenes.length} сцен, ${data.subtitles.length} субтитров. Добавь визуальные материалы.`);
});
on('#remove-voice', 'click', () => { project.voice_id = null; refresh(); });
on('#remove-music', 'click', () => { project.music_id = null; refresh(); });
on('#music-volume', 'input', e => { project.music_volume = Number(e.target.value)/100; save(); $('#volume-value').value = `${e.target.value}%`; });
on('#project-name', 'input', e => { project.name = e.target.value; save(); });
on('#scene-title', 'input', e => { project.scenes[selected].title = e.target.value; changed(); });
on('#scene-caption', 'input', e => { project.scenes[selected].caption = e.target.value; changed(); });
on('#scene-duration', 'change', e => {
  const value = Number(e.target.value);
  if (!Number.isFinite(value) || value < 1 || value > 30) { paintInspector(); throw new Error('Длительность сцены — от 1 до 30 секунд'); }
  project.scenes[selected].duration = Math.round(value*30)/30; refresh();
});
on('#scene-offset', 'change', e => {
  const value = Number(e.target.value), asset = media(project.scenes[selected].asset_id);
  if (!Number.isFinite(value) || value < 0 || value >= (asset?.duration || 1)) { paintInspector(); throw new Error('Начало фрагмента должно находиться внутри видео'); }
  project.scenes[selected].offset = value; refresh();
});
on('#scene-motion', 'change', e => { project.scenes[selected].motion = e.target.checked; refresh(); });
on('#motion-style', 'change', e => { project.scenes[selected].motion_style = e.target.value; save(); });
on('#scene-transition', 'change', e => { project.scenes[selected].transition_out = e.target.value; save(); });
on('#animate-titles', 'change', e => { project.animate_titles = e.target.checked; save(); });
on('#transition-sounds', 'change', e => { project.transition_sounds = e.target.checked; save(); });
on('#sfx-volume', 'input', e => { project.sfx_volume = Number(e.target.value)/100; $('#sfx-value').value = `${e.target.value}%`; save(); });
on('#clear-asset', 'click', () => { project.scenes[selected].asset_id = null; project.scenes[selected].offset = 0; refresh(); });
on('#transition', 'change', e => { project.transition = e.target.value; save(); });
on('#resolution', 'change', e => { project.resolution = e.target.value; changed(); });
$$('[data-template]').forEach(button => button.addEventListener('click', () => { project.scenes[selected].template = button.dataset.template; refresh(); }));
on('#add-scene', 'click', () => {
  if (project.scenes.length >= 40) throw new Error('Максимум 40 сцен');
  project.scenes.push({template:'cinema', title:'', caption:'', duration:4, asset_id:null, offset:0, motion:true});
  selected = project.scenes.length - 1; refresh(); $('#timeline').lastElementChild.scrollIntoView({behavior:'smooth', block:'nearest'});
});
on('#duplicate', 'click', () => {
  if (project.scenes.length >= 40) throw new Error('Максимум 40 сцен');
  project.scenes.splice(selected+1, 0, structuredClone(project.scenes[selected])); selected++; refresh();
});
on('#delete-scene', 'click', () => {
  if (project.scenes.length === 1) return;
  project.scenes.splice(selected, 1); selected = Math.min(selected, project.scenes.length - 1); refresh();
});
for (const [id, direction] of [['#move-left', -1], ['#move-right', 1]]) {
  on(id, 'click', () => {
    const target = selected + direction;
    if (target < 0 || target >= project.scenes.length) return;
    [project.scenes[target], project.scenes[selected]] = [project.scenes[selected], project.scenes[target]];
    selected = target; refresh();
  });
}
on('#demo', 'click', async () => {
  if (!confirm('Открыть демо-проект вместо текущего монтажа? Сначала скачай текущий проект, если хочешь его сохранить.')) return;
  project = await (await api('/api/demo')).json(); selected = 0; refresh(); toast('Открыт демо-проект. В нём нет озвучки.');
});
on('#save-project', 'click', () => {
  const url = URL.createObjectURL(new Blob([JSON.stringify(project, null, 2)], {type:'application/json'}));
  const link = document.createElement('a'); link.href = url; link.download = 'kadr-project.json'; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('Монтаж сохранён в JSON. Исходные файлы остаются на этом сервере.');
});
on('#import-project', 'click', () => $('#file-project').click());
on('#file-project', 'change', async e => {
  const file = e.target.files[0]; e.target.value = ''; if (!file) return;
  if (file.size > 2*1024*1024) throw new Error('Файл проекта слишком большой');
  let value; try { value = JSON.parse(await file.text()); } catch { throw new Error('Не удалось прочитать JSON проекта'); }
  const valid = await (await api('/api/project/validate', jsonPost(value))).json();
  if (!confirm('Заменить текущий монтаж открываемым проектом?')) return;
  project = valid; selected = 0; refresh(); toast('Проект открыт');
});
on('#close-export', 'click', () => $('#export-dialog').close());
async function pollJob(id) {
  if (polling) return;
  polling = true;
  const poll = async () => {
    try {
      const job = await (await api(`/api/jobs/${id}`)).json();
      $('#export-message').textContent = job.message;
      $('#export-progress').value = job.progress;
      $('#export-percent').textContent = `${job.progress}%`;
      if (job.status === 'done' || job.status === 'error') {
        polling = false; localStorage.removeItem('kadr-job'); $('#export').textContent = 'Экспорт MP4 ↗';
        if (job.status === 'error') { $('#export-heading').textContent = 'Экспорт не завершён'; toast(job.message, true); return; }
        $('#export-heading').textContent = 'Твоя история готова';
        const url = `/api/jobs/${id}/video`;
        $('#result-video').src = url; $('#result-video').classList.remove('hidden');
        $('#download-video').href = url; $('#download-video').classList.remove('hidden');
        if (!$('#export-dialog').open) { $('#export-dialog').showModal(); toast('Экспорт готов'); }
      } else { setTimeout(poll, 1000); }
    } catch (e) {
      polling = false; $('#export').textContent = 'Проверить экспорт ↗';
      $('#export-message').textContent = 'Связь прервалась. Нажми «Проверить экспорт», чтобы узнать результат.';
      toast(e.message, true);
    }
  };
  await poll();
}
on('#export', 'click', async () => {
  const oldId = localStorage.getItem('kadr-job');
  if (oldId) { $('#export-dialog').showModal(); await pollJob(oldId); return; }
  const missing = project.scenes.filter(s => !s.asset_id && s.template !== 'quote').length;
  const voice = media(project.voice_id);
  const warnings = [];
  if (missing) warnings.push(`${missing} сцен используют демонстрационный фон.`);
  if (!voice && !project.music_id) warnings.push(project.transition_sounds ? 'Озвучки нет: возможны только звуки переходов.' : 'Ролик будет без звука.');
  if (voice && voice.duration > duration()+.1) warnings.push('Озвучка длиннее монтажа: конец звука будет обрезан.');
  if (warnings.length && !confirm(warnings.join('\n') + '\n\nПродолжить экспорт?')) return;
  $('#export').disabled = true;
  try {
    const job = await (await api('/api/render', jsonPost(project))).json();
    localStorage.setItem('kadr-job', job.id);
    $('#result-video').classList.add('hidden'); $('#result-video').removeAttribute('src');
    $('#download-video').classList.add('hidden'); $('#export-progress').value = 0;
    $('#export-heading').textContent = 'Собираем твою историю';
    $('#export-message').textContent = 'Подготовка кадров';
    $('#export').textContent = 'Ход экспорта ↗'; $('#export-dialog').showModal(); await pollJob(job.id);
  } finally { $('#export').disabled = false; }
});
async function init() {
  assets = await (await api('/api/assets')).json();
  const saved = localStorage.getItem(storageKey);
  if (saved) {
    try {
      const candidate = JSON.parse(saved);
      // Retain an unfinished montage even when its durations currently conflict
      // with SRT timing. Export validation must not discard editable work.
      const templateNames = Object.keys(labels);
      if (!candidate || candidate.version !== 1 || typeof candidate.name !== 'string' || !Array.isArray(candidate.scenes) || !candidate.scenes.length || candidate.scenes.length > 40 ||
          !candidate.scenes.every(s => templateNames.includes(s.template) && typeof s.title === 'string' && typeof s.caption === 'string' && Number.isFinite(s.duration) && s.duration >= 1 && s.duration <= 30 && Number.isFinite(s.offset) && (!s.asset_id || /^[a-f0-9]{32}$/.test(s.asset_id))) ||
          !Array.isArray(candidate.subtitles) || !candidate.subtitles.every(c => typeof c.text === 'string' && Number.isFinite(c.start) && Number.isFinite(c.end))) throw new Error('Повреждённый проект');
      project = candidate;
    } catch {
      localStorage.setItem('kadr-project-recovery', saved);
      toast('Сохранённый проект повреждён. Резервная копия сохранена в браузере под ключом kadr-project-recovery.', true);
    }
  }
  if (!project) project = await (await api('/api/demo')).json();
  refresh();
  const job = localStorage.getItem('kadr-job');
  if (job) { $('#export').textContent = 'Ход экспорта ↗'; await pollJob(job); }
}
init().catch(e => {
  $('#connection-detail').textContent = e.message;
  $('#connection-error').classList.remove('hidden');
});
