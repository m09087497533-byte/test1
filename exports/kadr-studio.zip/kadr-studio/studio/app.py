import io
import json
import logging
import shutil
import subprocess
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import ValidationError

from .media import ASSETS, JOBS, ROOT, asset_info, asset_path, probe, run
from .models import Project, Scene, total_duration
from .render import preview, render, validate_assets
from .subtitles import parse_subtitles, plan_scenes

app = FastAPI(title='Кадр — видеомастерская', docs_url='/api/docs')
app.mount('/static', StaticFiles(directory=ROOT / 'static'), name='static')
worker = ThreadPoolExecutor(max_workers=1)
job_lock = threading.Lock()
jobs: dict[str, dict] = {}
Image.MAX_IMAGE_PIXELS = 24_000_000
logger = logging.getLogger('uvicorn.error')

# A restarted process cannot resume an encoder. Finished exports remain available.
for status_file in JOBS.glob('*/status.json'):
    try:
        state = json.loads(status_file.read_text())
        if state['status'] in ('queued', 'running'):
            state.update(status='error', message='Сервер был перезапущен. Запустите экспорт ещё раз.')
            status_file.write_text(json.dumps(state, ensure_ascii=False))
        jobs[status_file.parent.name] = state
    except (OSError, ValueError, KeyError):
        continue


@app.get('/')
def index():
    return FileResponse(ROOT / 'static' / 'index.html')


@app.get('/api/health')
def health():
    return {'ok': bool(shutil.which('ffmpeg') and shutil.which('ffprobe')), 'version': '0.1.0'}


@app.get('/api/assets')
def assets():
    result = []
    for path in sorted(ASSETS.glob('*/meta.json')):
        result.append(json.loads(path.read_text()))
    return result


@app.post('/api/assets')
async def upload(file: UploadFile = File(...)):
    identifier = uuid.uuid4().hex
    folder = ASSETS / identifier
    folder.mkdir()
    target = folder / 'source'
    size = 0
    try:
        with target.open('wb') as dest:
            while chunk := await file.read(1024*1024):
                size += len(chunk)
                if size > 256*1024*1024:
                    raise HTTPException(413, 'Максимальный размер файла — 256 МБ')
                dest.write(chunk)
        name = (file.filename or 'Материал')[:160]
        meta = {'id': identifier, 'name': name, 'size': size, 'has_audio': False}
        try:
            with Image.open(target) as source:
                source.load()
                image = ImageOps.exif_transpose(source).convert('RGB')
                image.save(folder / 'image.jpg', quality=95)
                image.thumbnail((640, 360))
                image.save(folder / 'thumb.jpg')
                meta.update(kind='image', file='image.jpg', duration=0)
            target.unlink()
        except (UnidentifiedImageError, OSError):
            # Whitelist demuxers; an uploaded playlist must not trigger URL/file reads.
            result = run(['ffprobe', '-v', 'error', '-protocol_whitelist', 'file,pipe',
                          '-format_whitelist', 'mov,matroska,webm,mp3,wav,ogg,flac,aac,avi',
                          '-show_format', '-show_streams', '-of', 'json', str(target)], timeout=30)
            info = json.loads(result.stdout)
            duration = float(info.get('format', {}).get('duration', 0))
            if not 0 < duration <= 36000:
                raise ValueError('Не удалось определить длительность файла')
            video = next((s for s in info['streams'] if s['codec_type'] == 'video'
                          and not s.get('disposition', {}).get('attached_pic')), None)
            has_audio = any(s['codec_type'] == 'audio' for s in info['streams'])
            if not video and not has_audio:
                raise ValueError('В файле нет изображения или звука')
            meta.update(kind='video' if video else 'audio', duration=duration, has_audio=has_audio, file='source')
            if video:
                if video['width']*video['height'] > 24_000_000:
                    raise ValueError('Максимальное разрешение — 24 мегапикселя')
                run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(target),
                     '-frames:v', '1', '-vf', 'scale=640:360:force_original_aspect_ratio=decrease',
                     '-threads', '2', str(folder / 'thumb.jpg')], timeout=60)
        (folder / 'meta.json').write_text(json.dumps(meta, ensure_ascii=False))
        return meta
    except HTTPException:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    except (ValueError, subprocess.SubprocessError, OSError, Image.DecompressionBombError) as exc:
        shutil.rmtree(folder, ignore_errors=True)
        raise HTTPException(400, 'Не удалось прочитать файл. Поддерживаются JPEG, PNG, WebP, MP4, MOV, MP3, WAV, M4A, OGG и FLAC.') from exc
    finally:
        await file.close()


@app.get('/api/assets/{identifier}/thumb')
def thumbnail(identifier: str):
    try:
        meta = asset_info(identifier)
        if meta['kind'] == 'audio':
            raise ValueError('Нет миниатюры')
        return FileResponse(ASSETS / identifier / 'thumb.jpg')
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get('/api/assets/{identifier}/file')
def original(identifier: str):
    try:
        meta = asset_info(identifier)
        return FileResponse(asset_path(identifier), filename=meta['name'])
    except ValueError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.post('/api/subtitles')
async def subtitles(file: UploadFile = File(...), voice_id: str = Form(default='')):
    try:
        content = await file.read(1024*1024 + 1)
        if len(content) > 1024*1024:
            raise ValueError('Файл субтитров слишком большой: максимум 1 МБ')
        try:
            text = content.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = content.decode('cp1251')
        cues = parse_subtitles(text)
        duration = asset_info(voice_id)['duration'] if voice_id else 0
        scenes = plan_scenes(cues, duration)
        return {'subtitles': [c.model_dump() for c in cues], 'scenes': [s.model_dump() for s in scenes]}
    except (ValueError, ValidationError) as exc:
        raise HTTPException(400, str(exc)) from exc
    finally:
        await file.close()


@app.post('/api/preview')
def scene_preview(scene: Scene):
    try:
        if scene.asset_id and asset_info(scene.asset_id)['kind'] == 'audio':
            raise ValueError('Аудиофайл нельзя использовать как изображение')
        out = io.BytesIO()
        preview(scene).save(out, format='JPEG', quality=90)
        return Response(out.getvalue(), media_type='image/jpeg')
    except (ValueError, subprocess.SubprocessError, OSError) as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post('/api/project/validate')
def validate(project: Project):
    try:
        validate_assets(project)
        return project.model_dump()
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


def perform_job(identifier: str, project: Project):
    folder = JOBS / identifier

    def update(percent, message, status='running'):
        with job_lock:
            state = {'id': identifier, 'status': status, 'progress': percent, 'message': message}
            jobs[identifier] = state
            temp = folder / 'status.tmp'
            temp.write_text(json.dumps(state, ensure_ascii=False))
            temp.replace(folder / 'status.json')
    try:
        render(project, folder, update)
        update(100, 'Ролик готов', 'done')
    except Exception as exc:
        logger.exception('Render failed: %s', identifier)
        if isinstance(exc, subprocess.CalledProcessError):
            logger.error('Encoder stderr: %s', exc.stderr[-4000:])
        update(0, 'Не удалось собрать ролик. Проверьте материалы; подробности — в журнале сервера.', 'error')


@app.post('/api/render', status_code=202)
def start_render(project: Project):
    try:
        validate_assets(project)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    with job_lock:
        if any(j['status'] in ('queued', 'running') for j in jobs.values()):
            raise HTTPException(409, 'Сначала дождитесь завершения текущего экспорта')
        identifier = uuid.uuid4().hex
        folder = JOBS / identifier
        folder.mkdir()
        (folder / 'project.json').write_text(project.model_dump_json(indent=2))
        state = {'id': identifier, 'status': 'queued', 'progress': 0, 'message': 'Подготовка экспорта'}
        jobs[identifier] = state
        (folder / 'status.json').write_text(json.dumps(state, ensure_ascii=False))
    worker.submit(perform_job, identifier, project)
    return state


@app.get('/api/jobs/{identifier}')
def job_status(identifier: str):
    with job_lock:
        if identifier not in jobs:
            raise HTTPException(404, 'Экспорт не найден')
        return dict(jobs[identifier])


@app.get('/api/jobs/{identifier}/video')
def video(identifier: str):
    state = job_status(identifier)
    if state['status'] != 'done':
        raise HTTPException(409, 'Видео ещё не готово')
    return FileResponse(JOBS / identifier / 'film.mp4', media_type='video/mp4', filename='film.mp4')


@app.get('/api/demo')
def demo():
    return Project(name='История, которая оживает', transition='mixed', transition_sounds=True, animate_titles=True, scenes=[
        Scene(title='У каждой истории\nесть свой голос', caption='Ваша озвучка. Ваш ритм. Ваш фильм.', duration=4),
        Scene(template='archive', title='Прошлое становится ближе', caption='АРХИВ • ГЛАВА 01', duration=4),
        Scene(template='statement', title='СИЛА СЛОВА', caption='Один акцент меняет всё', duration=3),
        Scene(template='quote', title='История начинается\nс одного слова', caption='Загрузите свою озвучку и SRT, чтобы создать собственный монтаж.', duration=5)
    ]).model_dump()
