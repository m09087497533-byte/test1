"""Choose and assign scene media from local assets and available search sources."""
import json
import re
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import image_search, stock_video
from .media import ASSETS, DATA
from .models import Project
from .network import connection_error

ROOT = DATA / 'auto-media'
ROOT.mkdir(exist_ok=True)


def tokens(text):
    return {word[:6] for word in re.findall(r'[a-zа-яё]{3,}', text.lower())
            if word not in image_search.STOP and word not in {'jpg','jpeg','png','mp4','file','image','video','old','ancient','historical','illuminated','person','human','photo','picture','landscape','footage'}}


def topic_words(text):
    expanded=text
    for stems,query,_ in image_search.CONCEPTS:
        if any(stem in text.lower() for stem in stems):expanded+=' '+query
    for stems,query in [(('горы','горах','горная','горный','горам'),'mountain path'),
                        (('путник','поход','тропа','идущий'),'hiking solitary person path'),
                        (('книга','книги','книгой'),'book manuscript'),
                        (('океан','море','морской'),'ocean coastline')]:
        if any(stem in text.lower() for stem in stems):expanded+=' '+query
    return tokens(expanded)


def scene_context(project, index):
    context = image_search.scene_query(project, index)
    footage = stock_video.footage_query(project, index)
    scene = project.scenes[index]
    text = (context['basis']+' '+scene.title+' '+scene.caption).lower()
    archive = any(s in text for s in ('рукопис','манускрип','енох','эфиоп','греческ','писание','папирус','летопис','документ','архив'))
    return {**context, 'video_query':footage['query'], 'preferred':'image' if archive else 'video',
            'words':topic_words(context['query']+' '+footage['query']+' '+text)}


def preferred_kinds(context, mode, index):
    if mode == 'photos': return ['image']
    if mode == 'videos': return ['video']
    return [context['preferred'], 'video' if context['preferred']=='image' else 'image']


def asset_words(asset):
    source = asset.get('provenance',{})
    return topic_words(' '.join(str(x) for x in (asset.get('name',''), source.get('query',''), source.get('description',''))))


def rank_candidate(item, context, duration, order=0, local=False):
    words = asset_words(item) if local else topic_words(str(item.get('title',''))+' '+str(item.get('description','')))
    overlap = len(words & context['words'])
    # Local files need an explicit text match; remote search order supplies a relevance signal.
    score = overlap*2 + (0 if local else 2/(order+1))
    width,height = item.get('width',0),item.get('height',0)
    if width and height:
        score += max(-1,1-abs(width/height-16/9))*.5
    length = item.get('duration',0)
    if item.get('kind')=='video' or item.get('provider'):
        score += .4 if length>=duration else -.4
    return score


def asset_identity(asset):
    return asset.get('provenance',{}).get('source_url') or asset.get('source_url') or asset.get('id')


def local_assets():
    items=[]
    for path in sorted(ASSETS.glob('*/meta.json')):
        try:
            item=json.loads(path.read_text())
            if item.get('kind') in ('image','video'):items.append(item)
        except (OSError,ValueError):continue
    return items


def assignment(index,asset,context,origin):
    is_video=asset['kind']=='video'
    # The editor can change the offset after automatic assignment.
    return {'scene_index':index,'asset':asset,'offset':0,
            'reason':f"{'Видео' if is_video else 'Фото'} · {context['concept']} · {origin}",
            'query':context['video_query'] if is_video else context['query']}


def arrange(project, mode, replace, update, cancelled):
    library=local_assets()
    used={asset_identity(a) for a in library if any(s.asset_id==a['id'] for s in project.scenes)} if not replace else set()
    available=[p for p in ('pexels','pixabay') if stock_video.get_key(p)]
    disabled=set(); cache={}; imported=[]; outcomes=[]; errors=[]
    total=len(project.scenes)

    def publish(index,message):
        update({'progress':round(index/total*100),'message':message,'assignments':list(imported),
                'outcomes':list(outcomes),'errors':list(dict.fromkeys(errors))})

    for index,scene in enumerate(project.scenes):
        if cancelled():break
        if scene.template in ('quote','thesis'):
            outcomes.append({'scene_index':index,'status':'skipped','reason':'Текстовая сцена использует собственный фон.'})
            publish(index+1,f'Сцена {index+1}: текстовый фон');continue
        if scene.asset_id and not replace:
            outcomes.append({'scene_index':index,'status':'kept','reason':'Сохранён назначенный материал.'})
            publish(index+1,f'Сцена {index+1}: материал сохранён');continue
        try:context=scene_context(project,index)
        except ValueError as exc:
            outcomes.append({'scene_index':index,'status':'missing','reason':str(exc)})
            publish(index+1,f'Сцена {index+1}: нужен текст для поиска');continue
        publish(index,f'Сцена {index+1} из {total}: {context["concept"]}')
        chosen=None
        kinds=preferred_kinds(context,mode,index)
        # Reuse a suitable downloaded file before spending network requests.
        local=[a for a in library if a['kind'] in kinds and asset_identity(a) not in used and
               asset_words(a)&context['words']]
        if local:
            best=max(local,key=lambda a:rank_candidate(a,context,scene.duration,local=True)+(1 if a['kind']==kinds[0] else 0))
            chosen=assignment(index,best,context,'из библиотеки')
        else:
            for kind in kinds:
                sources=['commons'] if kind=='image' else available
                candidates=[]
                query=context['query'] if kind=='image' else context['video_query']
                for provider in sources:
                    if cancelled():break
                    if provider in disabled:continue
                    key=(provider,query)
                    if key not in cache:
                        try:
                            cache[key]=image_search.search_images(query) if provider=='commons' else stock_video.search_videos(provider,query)
                        except (ValueError,OSError) as exc:
                            message=connection_error(exc,'Wikimedia Commons') if isinstance(exc,OSError) else str(exc)
                            errors.append(message)
                            disabled.add(provider);cache[key]=[]
                    for order,item in enumerate(cache[key]):
                        if asset_identity(item) not in used:
                            candidates.append((rank_candidate(item,context,scene.duration,order),provider,item))
                for _,provider,item in sorted(candidates,key=lambda c:c[0],reverse=True)[:3]:
                    if cancelled():break
                    try:
                        asset=image_search.import_image(item['token']) if provider=='commons' else stock_video.import_video(item['token'])
                        if cancelled():break
                        chosen=assignment(index,asset,context,'Wikimedia' if provider=='commons' else provider.title())
                        library.append(asset);break
                    except (ValueError,OSError) as exc:
                        errors.append(connection_error(exc,'Загрузка материала') if isinstance(exc,OSError) else str(exc))
                    except Exception:
                        # Encoder/parser errors must not expose private paths or provider URLs.
                        errors.append('Не удалось прочитать один из найденных материалов. Пробуем следующий.')
                if chosen or cancelled():break
        if cancelled():break
        if chosen:
            imported.append(chosen);used.add(asset_identity(chosen['asset']))
            outcomes.append({'scene_index':index,'status':'assigned','reason':chosen['reason']})
        else:
            reason='Подходящий материал не найден. Попробуйте уточнить заголовок сцены.'
            if mode=='videos' and not available:reason='Для поиска видео подключите Pexels или Pixabay либо загрузите подходящий футаж в библиотеку.'
            outcomes.append({'scene_index':index,'status':'missing','reason':reason})
        publish(index+1,f'Обработано {index+1} из {total} сцен')
    return {'assignments':imported,'outcomes':outcomes,'errors':list(dict.fromkeys(errors))}


class ArrangementJobs:
    def __init__(self,root=ROOT):
        self.root=Path(root);self.root.mkdir(exist_ok=True)
        self.lock=threading.Lock();self.pool=ThreadPoolExecutor(max_workers=1)
        self.states={};self.cancellations={}
        for file in self.root.glob('*/status.json'):
            try:
                state=json.loads(file.read_text())
                if state['status'] in ('queued','running','cancelling'):
                    state.update(status='interrupted',message='Подбор прерван перезапуском. Уже найденные материалы доступны; запустите подбор для оставшихся сцен.')
                    file.write_text(json.dumps(state,ensure_ascii=False))
                self.states[file.parent.name]=state
            except (OSError,ValueError,KeyError):continue

    def _write(self,identifier,state):
        folder=self.root/identifier
        temp=folder/'status.tmp';temp.write_text(json.dumps(state,ensure_ascii=False));temp.replace(folder/'status.json')

    def start(self,project,mode,replace):
        with self.lock:
            if any(s['status'] in ('queued','running','cancelling') for s in self.states.values()):
                raise ValueError('Дождитесь текущего подбора или остановите его.')
            identifier=uuid.uuid4().hex;(self.root/identifier).mkdir()
            (self.root/identifier/'project.json').write_text(project.model_dump_json(indent=2))
            state={'id':identifier,'status':'queued','progress':0,'message':'Подготовка автоматического подбора',
                   'assignments':[],'outcomes':[],'errors':[]}
            self.states[identifier]=state;self.cancellations[identifier]=threading.Event()
            self._write(identifier,state)
        self.pool.submit(self._run,identifier,project,mode,replace)
        return json.loads(json.dumps(state))

    def _run(self,identifier,project,mode,replace):
        event=self.cancellations[identifier]
        def update(changes):
            with self.lock:
                state=self.states[identifier]
                state.update(changes,status='cancelling' if event.is_set() else 'running')
                self._write(identifier,state)
        try:
            result=arrange(project,mode,replace,update,event.is_set)
            with self.lock:
                state=self.states[identifier]
                state.update(result,status='cancelled' if event.is_set() else 'done',progress=state['progress'] if event.is_set() else 100,
                             message='Подбор остановлен' if event.is_set() else f'Назначено материалов: {len(result["assignments"])}')
                self._write(identifier,state)
        except Exception:
            with self.lock:
                state=self.states[identifier];state.update(status='error',message='Подбор прерван из-за ошибки. Уже найденные материалы сохранены.')
                self._write(identifier,state)

    def get(self,identifier):
        with self.lock:
            if identifier not in self.states:raise KeyError(identifier)
            return json.loads(json.dumps(self.states[identifier]))

    def cancel(self,identifier):
        with self.lock:
            if identifier not in self.states:raise KeyError(identifier)
            if self.states[identifier]['status'] in ('queued','running','cancelling'):
                self.cancellations[identifier].set()
                self.states[identifier].update(status='cancelling',message='Останавливаем после текущего запроса…')
                self._write(identifier,self.states[identifier])
        return self.get(identifier)
