import math
import io
import shutil
import subprocess
from pathlib import Path
from functools import lru_cache

from PIL import Image, ImageDraw, ImageEnhance, ImageFont, ImageOps

from .media import asset_info, asset_path, run
from .models import Project, Scene, frame_count, total_duration
from .subtitles import ass_document
from .effects import assemble, transition_frames, synthesize_sfx

FONTS = Path(__file__).resolve().parent / 'fonts'


@lru_cache(maxsize=256)
def font(size: int, serif=False):
    return ImageFont.truetype(str(FONTS / ('DejaVuSerif.ttf' if serif else 'DejaVuSans-Bold.ttf')), size)


def wrapped(text: str, face, width: int) -> str:
    lines = []
    for paragraph in text.split('\n'):
        line = ''
        for word in paragraph.split():
            candidate = f'{line} {word}'.strip()
            if face.getlength(candidate) <= width:
                line = candidate
                continue
            if line:
                lines.append(line)
            line = ''
            for char in word:
                if face.getlength(line + char) > width and line:
                    lines.append(line)
                    line = ''
                line += char
        lines.append(line)
    return '\n'.join(lines)


def text_block(draw, text, box, size, fill, serif=False, center=False):
    if not text.strip():
        return
    x, y, width, height = box
    for current in range(size, 9, -1):
        face = font(current, serif)
        value = wrapped(text, face, width)
        spacing = max(4, current // 5)
        bounds = draw.multiline_textbbox((0, 0), value, font=face, spacing=spacing)
        if bounds[3] - bounds[1] <= height:
            break
    if center:
        x += (width - (bounds[2] - bounds[0])) / 2
        y += (height - (bounds[3] - bounds[1])) / 2
    draw.multiline_text((x, y - bounds[1]), value, font=face, fill=fill,
                        spacing=spacing, align='center' if center else 'left')


def backdrop(width: int, height: int) -> Image.Image:
    """Built-in abstract landscape, independent of the uploaded reference."""
    image = Image.new('RGB', (width, height), '#c7bea5')
    draw = ImageDraw.Draw(image)
    for y in range(height):
        v = y / height
        draw.line((0, y, width, y), fill=(int(209 - v * 40), int(199 - v * 38), int(174 - v * 28)))
    draw.ellipse((width*.65, height*.12, width*.78, height*.12+width*.13), fill='#e7d9b8')
    for layer, color in enumerate(['#a6a18b', '#7a8276', '#4b6057', '#293f39']):
        points = [(0, height)]
        for x in range(0, width + 5, 4):
            y = height * (.48 + layer*.12 + .09*math.sin(x/width*7 + layer*1.8) + .04*math.cos(x/width*19))
            points.append((x, y))
        points += [(width, height)]
        draw.polygon(points, fill=color)
    return image


def overlay(scene: Scene, size: tuple[int, int]) -> Image.Image:
    w, h = size
    layer = Image.new('RGBA', size)
    d = ImageDraw.Draw(layer)
    scale = w / 1280
    if scene.template == 'quote':
        d.rectangle((0, 0, w, h), fill='#c2c0ae')
        d.arc((-w*.12, h*.08, w*.23, h*.4), 255, 350, fill='#8b8a7a', width=max(1, int(2*scale)))
        box = (w*.14, h*.17, w*.86, h*.85)
        d.rectangle((box[0]+12*scale, box[1]+12*scale, box[2]+12*scale, box[3]+12*scale), fill='#aaa895')
        d.rectangle(box, fill='#f2eedc')
        d.text((w*.19, h*.23), 'И З   А Р Х И В А', font=font(int(13*scale)), fill='#918b77')
        d.rectangle((w*.19, h*.52, w*.55, h*.55), fill='#d7c368')
        text_block(d, scene.title, (w*.19, h*.31, w*.62, h*.22), int(56*scale), '#302f27', serif=True)
        d.line((w*.19, h*.61, w*.81, h*.61), fill='#c9c1a3', width=max(1, int(scale)))
        text_block(d, scene.caption, (w*.19, h*.65, w*.62, h*.14), int(25*scale), '#514c3e', serif=True)
    elif scene.template == 'thesis':
        d.rectangle((0,0,w,h), fill='#0b1110')
        for x in range(0,w,max(1,int(90*scale))):
            d.line((x,0,x,h),fill='#26332b',width=max(1,int(scale)))
        for y in range(0,h,max(1,int(90*scale))):
            d.line((0,y,w,y),fill='#26332b',width=max(1,int(scale)))
        text_block(d,scene.title.upper(),(w*.08,h*.28,w*.84,h*.40),int(104*scale),'#e1f266',center=True)
        text_block(d,scene.caption,(w*.1,h*.75,w*.8,h*.1),int(24*scale),'#c0c6aa',center=True)
    elif scene.template == 'statement':
        d.rectangle((0, 0, w, h), fill=(142, 5, 31, 195))
        text_block(d, scene.title.upper(), (w*.08, h*.24, w*.84, h*.44), int(110*scale), '#fff6e7', center=True)
        text_block(d, scene.caption, (w*.12, h*.77, w*.76, h*.12), int(24*scale), '#f1c8c3', center=True)
        d.rectangle((w*.46, h*.16, w*.54, h*.165), fill='#eac896')
    elif scene.template == 'archive':
        m = int(w*.08)
        d.rectangle((0, 0, w, m), fill='#101516')
        d.rectangle((0, h-m, w, h), fill='#101516')
        d.rectangle((0, 0, m, h), fill='#101516')
        d.rectangle((w-m, 0, w, h), fill='#101516')
        d.rectangle((m-5, m-5, w-m+5, h-m+5), outline='#c4d86b', width=max(1, int(2*scale)))
        d.rectangle((m, h*.69, w-m, h-m), fill=(9, 14, 14, 170))
        text_block(d, scene.title, (w*.12, h*.71, w*.76, h*.13), int(36*scale), '#f3f0e3')
        text_block(d, scene.caption, (w*.12, h*.91, w*.76, h*.055), int(16*scale), '#c4d86b')
    else:
        # A legible lower gradient; no text is baked into moving source material.
        for y in range(int(h*.35), h):
            alpha = int(190*max(0, (y/h-.35)/.65)**1.5)
            d.line((0, y, w, y), fill=(6, 13, 11, alpha))
        text_block(d, scene.title, (w*.08, h*.58, w*.84, h*.22), int(55*scale), '#fff8e9')
        text_block(d, scene.caption, (w*.08, h*.84, w*.84, h*.10), int(23*scale), '#e1dbc5')
    return layer


def tone(image: Image.Image, scene: Scene) -> Image.Image:
    if scene.template == 'archive':
        return ImageOps.colorize(ImageOps.grayscale(image), '#1c2421', '#e2ddc8')
    return ImageEnhance.Color(image).enhance(.78)


def source_still(scene: Scene, size: tuple[int, int]) -> Image.Image:
    if not scene.asset_id or scene.template == 'quote':
        return backdrop(*size)
    meta = asset_info(scene.asset_id)
    if meta['kind'] == 'video':
        result = subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error',
            '-ss', str(scene.offset), '-i', str(asset_path(scene.asset_id)), '-frames:v', '1',
            '-vf', f'scale={size[0]}:{size[1]}:force_original_aspect_ratio=increase,crop={size[0]}:{size[1]},setsar=1',
            '-threads', '2', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-'],
            capture_output=True, check=True, timeout=30)
        with Image.open(io.BytesIO(result.stdout)) as original:
            return original.convert('RGB')
    path = asset_path(scene.asset_id)
    with Image.open(path) as original:
        return ImageOps.fit(original.convert('RGB'), size, method=Image.Resampling.LANCZOS)


def preview(scene: Scene, size=(960, 540)) -> Image.Image:
    base = tone(source_still(scene, size), scene).convert('RGBA')
    return Image.alpha_composite(base, overlay(scene, size)).convert('RGB')


def validate_assets(project: Project):
    for scene in project.scenes:
        if scene.asset_id:
            meta = asset_info(scene.asset_id)
            if meta['kind'] not in ('image', 'video'):
                raise ValueError('Для сцены нужно изображение или видео')
            if meta['kind'] == 'video' and scene.offset >= meta['duration']:
                raise ValueError('Начало фрагмента выходит за пределы видео')
    for identifier in (project.voice_id, project.music_id):
        if identifier and not asset_info(identifier).get('has_audio'):
            raise ValueError('Выбранный файл не содержит звуковую дорожку')


def render(project: Project, folder: Path, progress):
    validate_assets(project)
    size = (1920, 1080) if project.resolution == '1080p' else (1280, 720)
    w, h = size
    pieces = []
    for index, scene in enumerate(project.scenes):
        progress(5 + int(index / len(project.scenes)*65), f'Сцена {index+1} из {len(project.scenes)}')
        frame_total = frame_count(scene) + transition_frames(project, index)
        duration = frame_total / 30
        decor = folder / f'overlay-{index}.png'
        overlay(scene, size).save(decor)
        is_video = scene.asset_id and asset_info(scene.asset_id)['kind'] == 'video' and scene.template != 'quote'
        args = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-filter_complex_threads', '1']
        if is_video:
            args += ['-ss', str(scene.offset), '-i', str(asset_path(scene.asset_id))]
            # Freeze the last frame when the chosen clip is shorter than the scene.
            saturation = '0' if scene.template == 'archive' else '.78'
            base_filter = (f'scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1,'
                           f'fps=30,eq=saturation={saturation},tpad=stop_mode=clone:stop={frame_total},setpts=N/(30*TB)')
        else:
            base = folder / f'base-{index}.jpg'
            tone(source_still(scene, size), scene).save(base, quality=95)
            args += ['-loop', '1', '-framerate', '30', '-i', str(base)]
            if scene.motion and scene.template != 'quote':
                step = f'on/{max(1,frame_total-1)}'
                zoom = f'1+0.085*{step}'
                x = 'iw/2-iw/zoom/2'
                if scene.motion_style == 'pull':
                    zoom = f'1.085-0.085*{step}'
                elif scene.motion_style in ('left', 'right'):
                    zoom = '1.10'
                    x = f'(iw-iw/zoom)*{step}' if scene.motion_style == 'left' else f'(iw-iw/zoom)*(1-{step})'
                base_filter = (f"scale={w*2}:{h*2},zoompan=z='{zoom}':"
                               f"x='{x}':y='ih/2-ih/zoom/2':d=1:s={w}x{h}:fps=30,setsar=1")
            else:
                base_filter = 'setsar=1'
        args += ['-loop', '1', '-framerate', '30', '-i', str(decor)]
        fade = f',fade=t=in:st=0:d=0.18,fade=t=out:st={duration-.18}:d=0.18' if project.transition == 'fade' else ''
        animated = project.animate_titles and scene.template != 'quote'
        decoration = '[1:v]format=rgba,fade=t=in:st=0:d=0.24:alpha=1[decor];' if animated else ''
        label = '[decor]' if animated else '[1:v]'
        position = f"0:'{int(h*.025)}*max(0,1-t/0.3)'" if animated else '0:0'
        graph = f'[0:v]{base_filter}[bg];{decoration}[bg]{label}overlay={position}:shortest=1{fade},format=yuv420p[out]'
        piece = folder / f'scene-{index:03d}.mp4'
        args += ['-filter_complex', graph, '-map', '[out]', '-an', '-frames:v', str(frame_total),
                 '-r', '30', '-fps_mode', 'cfr',
                 '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-threads', '2',
                 '-video_track_timescale', '15360', str(piece)]
        run(args, timeout=600)
        pieces.append(piece)
    video = assemble(project, pieces, folder, progress)
    progress(87, 'Сведение озвучки и звуков переходов')
    output = folder / 'film.mp4'
    audio_ids = [(asset_path(i), volume, role) for i,volume,role in
                 [(project.voice_id,1.0,'voice'),(project.music_id,project.music_volume,'music')] if i]
    sfx = folder / 'transitions.wav'
    if synthesize_sfx(project, sfx):
        audio_ids.append((sfx, 1.0, 'sfx'))
    args = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-filter_complex_threads', '1', '-i', str(video)]
    if audio_ids:
        filters = []
        for i, (path, volume, role) in enumerate(audio_ids, 1):
            args += ['-i', str(path)]
            music_fade = (f',afade=t=out:st={max(0,total_duration(project)-.7)}:d=0.7'
                          if role == 'music' else '')
            filters.append(f'[{i}:a]aresample=48000,asetpts=PTS-STARTPTS,volume={volume},apad{music_fade}[a{i}]')
        labels = ''.join(f'[a{i}]' for i in range(1, len(audio_ids)+1))
        duration = total_duration(project)
        filters.append(f'{labels}amix=inputs={len(audio_ids)}:normalize=0,alimiter=limit=0.95:level=0[audio]')
        args += ['-filter_complex', ';'.join(filters), '-map', '0:v', '-map', '[audio]',
                 '-c:a', 'aac', '-b:a', '192k', '-t', str(duration)]
    else:
        args += ['-map', '0:v', '-an']
    if project.subtitles:
        subs = folder / 'captions.ass'
        subs.write_text(ass_document(project.subtitles, w, h), encoding='utf-8')
        for path in FONTS.glob('*.ttf'):
            shutil.copy2(path, folder / path.name)
        # Use a relative, generated filename so client text never enters filter syntax.
        args += ['-vf', 'ass=captions.ass:fontsdir=.', '-c:v', 'libx264', '-preset', 'veryfast',
                 '-crf', '20', '-threads', '2']
    else:
        args += ['-c:v', 'copy']
    args += ['-movflags', '+faststart', str(output)]
    subprocess.run(args, cwd=folder, capture_output=True, text=True, check=True, timeout=600)
    # Retain only the project, status and final deliverable.
    for path in folder.iterdir():
        if path.name not in ('film.mp4', 'project.json', 'status.json'):
            path.unlink()
    progress(100, 'Ролик готов')
    return output
