import math
import re
import html

from .models import Scene, Subtitle

TIMESTAMP = r'(\d{2}):(\d{2}):(\d{2})[,.](\d{3})'
TIMING = re.compile(r'^' + TIMESTAMP + r'\s*-->\s*' + TIMESTAMP + r'\s*$')
VTT_TIME = r'(?:(\d{2,}):)?(\d{2}):(\d{2})\.(\d{3})'
VTT_TIMING = re.compile(r'^' + VTT_TIME + r'\s+-->\s+' + VTT_TIME + r'(?:\s+.*)?$')


def parse_subtitles(source: str) -> list[Subtitle]:
    normalized = source.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n').strip()
    if not re.match(r'^WEBVTT(?:[ \t\n]|$)', normalized):
        return parse_srt(normalized)
    blocks = re.split(r'\n[ \t]*\n', normalized)
    result = []
    for block in blocks[1:]:
        lines = block.split('\n')
        if re.match(r'^(NOTE(?:\s|$)|STYLE\s*$|REGION\s*$)', lines[0]):
            continue
        if '-->' not in lines[0]:
            lines = lines[1:]  # Optional WebVTT cue identifier.
        match = VTT_TIMING.match(lines[0].strip()) if lines else None
        if not match or len(lines) < 2:
            raise ValueError('Не удалось прочитать VTT: нужен таймкод и текст в каждом блоке')
        groups = tuple(v or '0' for v in match.groups())
        text = '\n'.join(lines[1:]).strip()
        # WebVTT styling, speaker labels and karaoke timestamp markup are not
        # executable instructions and are not burned into the caption text.
        text = html.unescape(re.sub(r'<[^>]*>', '', text))
        cue = Subtitle(start=seconds(groups[:4]), end=seconds(groups[4:]), text=text)
        if result and cue.start < result[-1].start:
            raise ValueError('Субтитры должны идти по возрастанию времени')
        result.append(cue)
    if not result:
        raise ValueError('VTT-файл не содержит субтитров')
    if len(result) > 2000:
        raise ValueError('Максимум 2000 субтитров')
    return result


def seconds(parts):
    h, m, s, ms = map(int, parts)
    if m >= 60 or s >= 60:
        raise ValueError('Некорректный таймкод SRT')
    return h*3600 + m*60 + s + ms/1000


def parse_srt(source: str) -> list[Subtitle]:
    source = source.lstrip('\ufeff').replace('\r\n', '\n').replace('\r', '\n').strip()
    if not source:
        raise ValueError('SRT-файл пуст')
    result = []
    for block in re.split(r'\n[ \t]*\n', source):
        lines = block.split('\n')
        if lines[0].strip().isdigit():
            lines = lines[1:]
        match = TIMING.match(lines[0].strip()) if lines else None
        if not match or len(lines) < 2:
            raise ValueError('Не удалось прочитать SRT: нужен таймкод и текст в каждом блоке')
        text = re.sub(r'</?(?:b|i|u|font)(?:\s[^>]*)?>', '', '\n'.join(lines[1:]).strip(), flags=re.I)
        cue = Subtitle(start=seconds(match.groups()[:4]), end=seconds(match.groups()[4:]), text=text)
        if result and cue.start < result[-1].start:
            raise ValueError('Субтитры должны идти по возрастанию времени')
        result.append(cue)
    if len(result) > 2000:
        raise ValueError('Максимум 2000 субтитров')
    return result


def plan_scenes(cues: list[Subtitle], minimum_duration: float = 0) -> list[Scene]:
    """Cut near cue boundaries, retaining original subtitle timings and gaps."""
    end = max(max(c.end for c in cues), minimum_duration, 1)
    if end > 600:
        raise ValueError('Первая версия поддерживает ролики до 10 минут')
    end_frame = math.ceil(end*30)
    boundaries = [0]
    for cue in cues:
        frame = round(cue.start*30)
        if frame - boundaries[-1] >= 8*30 and end_frame - frame >= 30:
            # Also split long silent intervals into valid <=30 second scenes.
            while frame - boundaries[-1] > 30*30:
                boundaries.append(boundaries[-1] + 20*30)
            boundaries.append(frame)
    while end_frame - boundaries[-1] > 30*30:
        boundaries.append(boundaries[-1] + 20*30)
    if end_frame - boundaries[-1] < 30 and len(boundaries) > 1:
        boundaries.pop()
    boundaries.append(end_frame)
    scenes = [Scene(duration=(b-a)/30) for a, b in zip(boundaries, boundaries[1:])]
    if len(scenes) > 40:
        # A long narration uses uniform 20-second scenes, still frame aligned.
        count = math.ceil(end_frame / 600)
        boundaries = [round(i*end_frame/count) for i in range(count+1)]
        scenes = [Scene(duration=(b-a)/30) for a, b in zip(boundaries, boundaries[1:])]
    return scenes


def ass_time(t: float) -> str:
    total = round(t*100)
    return f'{total//360000}:{total//6000%60:02}:{total//100%60:02}.{total%100:02}'


def ass_document(cues: list[Subtitle], width: int, height: int) -> str:
    header = f'''[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,{round(height*.042)},&H00FFFFFF,&H00FFFFFF,&H00101010,&H80000000,-1,0,0,0,100,100,0,0,1,2,1,2,{round(width*.08)},{round(width*.08)},{round(height*.035)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    for cue in cues:
        # Treat uploaded subtitles as literal text, never ASS commands.
        text = cue.text.replace('\\', '＼').replace('{', '｛').replace('}', '｝').replace('\n', r'\N')
        header += f'Dialogue: 0,{ass_time(cue.start)},{ass_time(cue.end)},Default,,0,0,0,,{text}\n'
    return header
